import { Component, ElementRef, HostListener, Input, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { reservationModel } from './reservationModel'
import { environment } from 'src/environments/environment';
import { BreakpointObserver, BreakpointState } from '@angular/cdk/layout';

@Component({
  selector: 'app-information-modal',
  templateUrl: './information-modal.component.html',
  styleUrls: ['./information-modal.component.css']
})

export class InformationModalComponent implements OnInit {

  @Input() businessId = '';

  constructor(private httpClient: HttpClient, private breakpointObserver: BreakpointObserver,) { }

  businessDetails!: any;

  detailsResult!: any;

  reviewResult!: any;

  isDataAvailable: boolean = false;

  businessCategories: any[] = new Array();

  reservationDetailJson: reservationModel = {
    name: '',
    email: '',
    date: '',
    time: ''
  };
  reservationExists: boolean = false;

  @ViewChild('noteModal') noteModal: ElementRef | undefined;

  email!: string;
  date!: string;
  time!: string;
  isEmailPresent: boolean = true;
  isDatePresent: boolean = true;
  isTimePresent: boolean = true;

  //Map related
  center: google.maps.LatLngLiteral = { lat: 24, lng: 12 };
  zoom = 12;
  markerOptions: google.maps.MarkerOptions = { draggable: false };
  markerPositions: google.maps.LatLngLiteral[] = [];
  mapWidth: string = '720px';

  jsonStorageObj: any = {};

  el!: HTMLElement;
  ngOnInit(): void {



    // detect screen size changes
    this.breakpointObserver.observe([
      "(max-width: 510px)"
    ]).subscribe((result: BreakpointState) => {
      if (result.matches) {
        console.log('width', window.innerWidth);
        // this.el.width = 
        this.mapWidth = '420px';
      } else {
        this.mapWidth = '700px';
      }
    });

    let resData = localStorage.getItem('reservations');

    if (resData == null) {
      this.jsonStorageObj = {};
    } else {
      this.jsonStorageObj = JSON.parse(resData);
    }

    var forms = document.querySelectorAll('.needs-validation')

    // Loop over them and prevent submission
    Array.prototype.slice.call(forms)
      .forEach(function (form) {
        form.addEventListener('submit', function (event: any) {
          console.log('submit form called')
          if (!form.checkValidity()) {
            event.preventDefault()
            event.stopPropagation()
          }

          form.classList.add('was-validated')
        }, false)
      })
  }

  ngOnChanges(changes: SimpleChanges) {
    let change = changes['businessId'];

    if (change.isFirstChange()) {
      return;
    }

    console.log("change detected");

    let newVal = change.currentValue;
    console.log('new val - ' + newVal);

    if (newVal.includes("<same_name>")) {
      newVal = newVal.replace("<same_name>", "");
    }

    this.businessId = newVal;

    console.log(newVal);

    let url = environment.api_address + '/getBusinessDetails/' + newVal;

    this.httpClient.get(url).subscribe((res: any) => {
      this.detailsResult = res;

      this.businessCategories = [];

      for (const category in this.detailsResult.categories) {
        const val = this.detailsResult.categories[category];
        this.businessCategories.push(val.title);
      }

      this.center.lat = this.detailsResult.coordinates.latitude;
      this.center.lng = this.detailsResult.coordinates.longitude;
      this.markerPositions = [];
      this.markerPositions.push(this.center);

      this.isDataAvailable = true;

      let review_url = url + "/reviews";

      this.httpClient.get(review_url).subscribe((res2: any) => {
        this.reviewResult = res2;
      })

      let temp: JSON = JSON.parse(localStorage.getItem("reservations") || '{}');
      if (temp.hasOwnProperty(this.detailsResult.id)) {
        this.reservationExists = true;
      } else {
        this.reservationExists = false;
      }
    })
  }

  onModalClose() {
    this.detailsResult = {};
    this.isDataAvailable = false;
  }

  onSubmitReservation(business: any) {
    if (this.email == undefined || this.email == '') {
      this.isEmailPresent = false;
      return;
    }
    if (this.date == undefined || this.date == '') {
      this.isDatePresent = false;
      return;
    }
    if (this.time == undefined || this.time == '') {
      this.isTimePresent = false;
      return;
    }

    console.log('email - ', this.email)
    console.log('date - ', this.date)
    console.log('time - ', this.time)
    console.log('id - ' + business.id)
    console.log('name - ' + business.name)

    this.reservationDetailJson.name = business.name;
    this.reservationDetailJson.email = this.email;
    this.reservationDetailJson.date = this.date;
    this.reservationDetailJson.time = this.time;

    let dataToStore: any = {};
    dataToStore['name'] = business.name;
    dataToStore['date'] = this.date;
    dataToStore['time'] = this.time;
    dataToStore['email'] = this.email;

    this.jsonStorageObj[business.id] = dataToStore;

    localStorage.setItem('reservations', JSON.stringify(this.jsonStorageObj));

    alert('Reservation has been created.');

    this.reservationExists = true;

    var el = document.getElementById('reservationModalCloseBtn')!;
    el.click();
    this.closeReservationForm();

  }

  closeReservationForm() {
    var el = <HTMLFormElement>document.getElementById('reservation-form')!;
    el.reset();
  }

  cancelReservationClicked(id: string) {

    delete this.jsonStorageObj[id];
    localStorage.setItem('reservations', JSON.stringify(this.jsonStorageObj));
    alert("Reservation cancelled!");
    this.reservationExists = false;
  }

  onResize(event: any) {
    let width = event.target.innerWidth;
    console.log(event.target.innerWidth);
    if (width < 576) {
      this.mapWidth = width - 20 + 'px';
    }
  }
}
