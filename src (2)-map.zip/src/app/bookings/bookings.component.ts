import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { map } from 'jquery';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-bookings',
  templateUrl: './bookings.component.html',
  styleUrls: ['./bookings.component.css']
})
export class BookingsComponent implements OnInit {

  constructor(private httpClient: HttpClient) { }


  reservationList: any = [];
  isReservationPresent: boolean = false;
  dataAvailable: boolean = false;

  jsonStorageObj: any = {};

  ngOnInit(): void {

    let resData = localStorage.getItem('reservations');

    if (resData == null) {
      this.jsonStorageObj = {};
    } else {
      this.jsonStorageObj = JSON.parse(resData);
    }

    // console.log(res);
    // var str = JSON.stringify(res);
    // console.log('str', str)

    var map = new Map(Object.entries(this.jsonStorageObj))
    console.log(map);
    this.reservationList = map;

    if (map.size > 0) {
      this.isReservationPresent = true;
    } else {
      this.isReservationPresent = false;
    }
    this.dataAvailable = true;

  }

  getValues(map: any[]) {
    return Array.from(map.values());
  }

  getValueFromKey(key: any) {
    return this.reservationList.get(key);
  }

  cancelReservationClicked(id: any) {
    delete this.jsonStorageObj[id];
    localStorage.setItem('reservations', JSON.stringify(this.jsonStorageObj));
    alert("Reservation cancelled!");

    this.reservationList.delete(id);
    console.log(this.reservationList);

    if (this.reservationList.size == 0) {
      this.isReservationPresent = false;
    }
  }
}
