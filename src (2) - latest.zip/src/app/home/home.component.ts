import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Observable, Subject } from 'rxjs';
import { catchError, map, startWith } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {

  term$ = new Subject<string>();

  constructor(private httpClient: HttpClient) {
    this.term$.pipe(
      debounceTime(100),
      distinctUntilChanged()
    ).subscribe(term => {
      this.keywordModelChange(term);
    });
  }

  userForm = new FormGroup({});

  control = new FormControl('');
  options: string[] = [];
  filteredOptions!: Observable<string[]>;
  autoDetectCheckBox: any;
  location!: string;
  dist!: number;
  keyword!: string;

  categories: string[] = [];
  categoriesJSON: any;
  selectedCategory: string = "Default";
  catDisabled: boolean = false;

  options$!: Observable<string[]>;

  showResults: boolean = false;
  resultsAvailable: boolean = true;

  jsonResults: any[] = [];

  buisnessIdSelected!: string;

  ipInfoApiKey: string = '4e2c4add7d4bf5';

  ngOnInit(): void {
  }

  autoDetectCheckBoxClicked(value: any) {
    if (value != true) {
      this.location = '';
    }
  }

  keywordModelChange(value: string) {
    console.log(value);
    if (value == '' || value == undefined) {
      return;
    }
    this.httpClient.get(environment.api_address + '/autocomplete?text=' + value)
      .subscribe((res: any) => {
        console.log(res)
        // var r = JSON.parse(res);      
        var terms = res.terms;

        this.categoriesJSON = res.categories;
        this.categories = [];
        for (let category in this.categoriesJSON) {
          this.categories.push(this.categoriesJSON[category].title);
        }

        if (this.categories.length == 0) {
          this.categories.push("No category avaialble");
          this.catDisabled = true;
        } else {
          this.catDisabled = false;
        }

        console.log(this.categories);

        var arr: string[] = [];

        for (let t in terms) {
          console.log(terms[t])
          arr.push(terms[t].text);
        }
        this.options = arr;

      })
  }

  onCategoryChanged(val: string) {
    this.selectedCategory = val;
  }

  async onSubmitClicked() {  

    let el = <HTMLFormElement>document.getElementById('form')!;


    let url = environment.api_address + '/search?'

    url += 'keyword=' + this.keyword + '&distance=' + this.dist;

    /**Check location */
    if (!this.autoDetectCheckBox) {
      url += '&location=' + this.location;
    }else{
      //Get latitude & longitude using ipinfo api
      let ipInfoUrl = "https://ipinfo.io/?token=" + this.ipInfoApiKey;

      let res: any = await this.httpClient.get(ipInfoUrl).toPromise();

      // await this.httpClient.get(ipInfoUrl).subscribe((res: any) => {
        console.log('ipInfo reply - ' + res);
        let loc = res.loc;
        url += '&latitude=' + loc.split(',')[0];
        url += '&longitude=' + loc.split(',')[1];
      // })
    }

    // let cat; ;
    // if (this.selectedCategory === 'No category avaialble') {
    //   cat = '';
    // } else {
    //   for (const c in this.categoriesJSON) {
    //     console.log(this.categoriesJSON[c].title, ' - ', this.selectedCategory);
    //     if (this.categoriesJSON[c].title == this.selectedCategory) {
    //       cat = this.categoriesJSON[c].alias;
    //       break;
    //     }
    //   }      
    // }

    url += '&categories=' + this.selectedCategory;

    if (this.keyword == undefined
      || this.dist == undefined
      || this.selectedCategory == undefined
      || (this.location == undefined && this.autoDetectCheckBox != false)) {

      console.log('Form is not valid')
      return;
    }

    let inRequest = false;

    this.httpClient.get(url).subscribe((res: any) => {

      console.log('got results - ' + res.businesses.length);
      console.log(res)
      this.jsonResults = res.businesses;

      this.jsonResults.splice(10);

      if (this.jsonResults.length == 0) {
        this.resultsAvailable = false;
      } else {
        this.resultsAvailable = true;
      }

      inRequest = true;

      //show the results data
      this.showResults = true;

    }, (error: any) => {
      console.log('error -> ' + error)
      this.showResults = true;
      this.resultsAvailable = false;      
    })

    console.log(inRequest);

    console.log('location - ', this.location, '||')
    console.log('keyword - ', this.keyword, '||')
    console.log('cat - ', this.selectedCategory, '||')
    console.log('dista - ', this.dist, '||')
    console.log(url)
  }

  onResultRowClick(val: string) {
    console.log('business cliked  ' + val);

    if (this.buisnessIdSelected == val) {
      //if same business is clicked again, the value change will not get triggered
      //and the pop up will not open. So need to do this workaround
      console.log('sending temp name')
      this.buisnessIdSelected = val + "<same_name>";
    } else {
      this.buisnessIdSelected = val;
    }
  }

  onClearClicked() {

    console.log('location - ', this.location, '||')
    console.log('keyword - ', this.keyword, '||')
    console.log('cat - ', this.selectedCategory, '||')
    console.log('dista - ', this.dist, '||')

    this.autoDetectCheckBox = false;

    this.jsonResults = [];

    this.showResults = false;
  }

  
}
