import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { map } from 'jquery';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-bookings',
  templateUrl: './bookings.component.html',
  styleUrls: ['./bookings.component.css']
})
export class BookingsComponent implements OnInit {

  constructor(private httpClient: HttpClient) { }


  reservationList: any = [];
  isReservationPresent: boolean = false;
  dataAvailable: boolean = false;

  ngOnInit(): void {

    let url = environment.api_address + "/listReservations";

    this.httpClient.get(url).subscribe((res: any) => {

      console.log(res);
      var str = JSON.stringify(res);
      console.log('str', str)

      var map = new Map(Object.entries(res))
      console.log(map);
      this.reservationList = map;

      if (map.size > 0) {
        this.isReservationPresent = true;
      } else {
        this.isReservationPresent = false;
      }
      this.dataAvailable = true;
    }, (error: any) => {
      console.log('error -> ' + error)
      this.dataAvailable = true;
    })

  }

  getValues(map: any[]) {
    return Array.from(map.values());
  }

  getValueFromKey(key: any){    
    return this.reservationList.get(key);
  }

  cancelReservationClicked(id: any){
    let url = environment.api_address + "/deleteRegistration/" + id.trim();
    console.log(url);
    this.httpClient.delete(url).subscribe((res: any) => {
      console.log(res);
      if (res.message == 'Reservation deleted!') {
        alert("Reservation cancelled!");        
      }
    })
     this.reservationList.delete(id);
    console.log(this.reservationList)

    if (this.reservationList.size == 0) {
      this.isReservationPresent = false;
    }
  }
}
