export interface reservationModel {
  name: string;
  email: string;
  date: string;
  time: string;
}