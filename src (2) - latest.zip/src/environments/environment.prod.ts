export const environment = {
  production: true,
  api_address: "https://nodeservice-dot-business-page-367419.wl.r.appspot.com"
};
