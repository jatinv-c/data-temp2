module pro.Aquarium {
    requires javafx.controls;
	requires javafx.graphics;
    exports pro.Aquarium;
}
