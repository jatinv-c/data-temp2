package pro.Aquarium;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

public class FishObject extends GameObject {

	public FishObject(Image img, GraphicsContext gc, double x, double y) {
		super(gc, x, y);
		super.img = img;
	}

}
