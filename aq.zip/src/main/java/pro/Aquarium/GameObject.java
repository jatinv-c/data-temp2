package pro.Aquarium;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

/**
 * GameObect Class Changed the dimension in update method to increase size of
 * the images created when update is called
 */
public class GameObject {

    protected Image img;
    protected double x, y;
    protected GraphicsContext gc;

    public GameObject(GraphicsContext gc, double x, double y) {
        this.gc = gc;
        this.x = x;
        this.y = y;
    }

    public void update() {
        if (img != null) {
            //dimension changed to 30 height and width
            gc.drawImage(img, x, y, img.getHeight(), img.getWidth());
        }
    }

}
