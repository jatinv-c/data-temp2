package pro.Aquarium;

import java.io.File;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

/**
 * Factory class to get fish objects based on the type
 *
 */
public class FishObjectFactory {

	public static FishObject getGameObject(String fishType, GraphicsContext gc, int width, int height) {
		
		FishObject fishObject = null;
		
		if (fishType.equalsIgnoreCase("blue")) {
			Image img = new Image(new File("fish-blue.png").toURI().toString(), width, height, false, false);
			fishObject = new FishObject(img, gc, 0, 0);	
			
		} else if (fishType.equalsIgnoreCase("red")) {
			Image img = new Image(new File("fish-red.png").toURI().toString(), width, height, false, false);
			fishObject = new FishObject(img, gc, 0, 0);
			
		} else if (fishType.equalsIgnoreCase("crab")) {
			Image img = new Image(new File("fish-crab.png").toURI().toString(), width, height, false, false);
			fishObject = new FishObject(img, gc, 0, 0);
			
		}
		return fishObject;
	}
	
}
