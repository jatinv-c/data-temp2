package pro.Aquarium;

import java.io.File;

import javafx.animation.AnimationTimer;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

public class View {

	Pane root;

	private final int FISH_HEIGHT = 75;
	private final int FISH_WIDTH = 75;
	private final int FOOD_HEIGHT = 50;
	private final int FOOD_WIDTH = 50;

	Canvas fish1Canvas;
	AnimationTimer fish1Animation;
	
	Canvas redFishCanvas;
	AnimationTimer redFishAnimation;
	
	Canvas crabFishCanvas;
	AnimationTimer crabFishAnimation;
	
	Canvas food1Canvas;
	
	Canvas shellCanvas1;
	Canvas shellCanvas2;
	Canvas shellCanvas3;

	/**
	 * Creates the ui
	 * @return
	 */
	public Parent createView() {

		root = new Pane();

		root.setPrefWidth(App.SCREEN_WIDTH - 80);
		root.setPrefHeight(App.SCREEN_HEIGHT);

		// create a backgorund for the grid pane
		BackgroundImage myBI = new BackgroundImage(
				new Image(new File("bg.jpg").toURI().toString(), root.getHeight(), root.getWidth(), false, false),
				BackgroundRepeat.ROUND, BackgroundRepeat.ROUND, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);

		// then you set to your grid pane
		root.setBackground(new Background(myBI));

		createFishObjects();	
		
		createShell();				

		root.getChildren().addAll(fish1Canvas, redFishCanvas, crabFishCanvas);

		Button startFishButton = new Button("Start Fish");
		startFishButton.setOnAction(e -> {
			startFishMovement();
		});

		Button stopFishButton = new Button("Stop Fish");
		stopFishButton.setOnAction(e -> {
			stopFishMovement();
		});

		Button dropFoodButton = new Button("Drop Food");
		dropFoodButton.setOnAction(e -> {			
			createFoodObjects();
//			timerFood1.start();
		});

		Button dropStopFoodButton = new Button("Sleep");
		dropStopFoodButton.setOnAction(e -> {
			if (dropStopFoodButton.getText().contains("Sleep")) {
				//For sleep
				stopFishMovement();
				shellCanvas1.setVisible(true);
				shellCanvas2.setVisible(true);
				shellCanvas3.setVisible(true);
				createShellAnimation(fish1Canvas);
				createShellAnimation(redFishCanvas);
				createShellAnimation(crabFishCanvas);
				dropStopFoodButton.setText("Wake");
			}else {
				//For Wake up
				shellCanvas1.setVisible(false);
				shellCanvas2.setVisible(false);
				shellCanvas3.setVisible(false);
				crabFishCanvas.setVisible(true);
				fish1Canvas.setVisible(true);
				redFishCanvas.setVisible(true);
				dropStopFoodButton.setText("Sleep");
			}			
		});

		VBox controlsVBox = new VBox();

		controlsVBox.setSpacing(40);
		controlsVBox.setAlignment(Pos.CENTER);
		controlsVBox.setPrefHeight(Integer.MAX_VALUE);
		controlsVBox.getChildren().addAll(startFishButton, stopFishButton, dropFoodButton, dropStopFoodButton);

		HBox containerMainHBox = new HBox();

		containerMainHBox.getChildren().addAll(root, controlsVBox);

		return containerMainHBox;
	}

	/**
	 * Creates Fish objects
	 */
	public void createFishObjects() {
		
		// Blue Fish
		fish1Canvas = new Canvas(FISH_WIDTH, FISH_HEIGHT);
		FishObjectFactory.getGameObject("blue", fish1Canvas.getGraphicsContext2D(), FISH_WIDTH, FISH_HEIGHT).update();
		fish1Canvas.setLayoutX(50);
		fish1Canvas.setLayoutY(75);

		fish1Animation = createAnimationForFish(fish1Canvas, false);

		//Red Fish
		redFishCanvas = new Canvas(FISH_WIDTH, FISH_HEIGHT);
		FishObjectFactory.getGameObject("red", redFishCanvas.getGraphicsContext2D(), FISH_WIDTH, FISH_HEIGHT).update();
		redFishCanvas.setTranslateX(500);
		redFishCanvas.setLayoutY(200);		

		redFishAnimation = createAnimationForFish(redFishCanvas, true);

		//Crab Fish
		crabFishCanvas = new Canvas(FISH_WIDTH, FISH_HEIGHT);
		FishObjectFactory.getGameObject("crab", crabFishCanvas.getGraphicsContext2D(), FISH_WIDTH, FISH_HEIGHT).update();
		crabFishCanvas.setLayoutX(50);
		crabFishCanvas.setLayoutY(400);		

		crabFishAnimation = createAnimationForFish(crabFishCanvas, false);
	}

	/**
	 * Create Animation FOr fish movement
	 * @param canvas
	 * @param reverseDirection - determines if fish moves left to right or tight to left
	 * @return
	 */
	public AnimationTimer createAnimationForFish(Canvas canvas, boolean reverseDirection) {
		
		if (reverseDirection) {
			canvas.setScaleX(-1);
		}
		
		AnimationTimer animation = new AnimationTimer() {					
			boolean reverse = reverseDirection;

			@Override
			public void handle(long now) {							
							
				if (reverse) {
					canvas.setTranslateX(canvas.getTranslateX() - 1);
				} else {
					canvas.setTranslateX(canvas.getTranslateX() + 1);
				}
				
				if ((canvas.getTranslateX() + 150) > root.getWidth()) {
					reverse = true;					
					canvas.setScaleX(-1);					
				}

				if (canvas.getTranslateX() < 10) {
					reverse = false;					
					canvas.setScaleX(1);					
				}							
			}
		};

		return animation;
	}

	/**
	 * Start Fish Movement
	 */
	public void startFishMovement() {
		fish1Animation.start();
		redFishAnimation.start();
		crabFishAnimation.start();
	}

	/**
	 * Stop fish movement
	 */
	public void stopFishMovement() {
		fish1Animation.stop();
		redFishAnimation.stop();
		crabFishAnimation.stop();
	}	
	
	/**
	 * Creates the food objects
	 */
	public void createFoodObjects() {				
		
		int[] xFoodArr = Singleton.getInstance().getFoodXArr();
		
		for (int i = 0; i < xFoodArr.length; i++) {
			Canvas c = Singleton.getInstance().getNewFoodObject();
			root.getChildren().add(c);
			c.setLayoutX(xFoodArr[i]);
			c.setLayoutY(0);
			startFoodAnimation(c);
		}
	}	
	
	/**
	 * Start dropping food
	 * @param canvas
	 */
	public void startFoodAnimation(Canvas canvas) {				
		AnimationTimer timerFood1 = createFoodAnimation(canvas);		
		timerFood1.start();		
	}
	
	/**
	 * Create animation for falling food
	 * @param canvas
	 * @return
	 */
	public AnimationTimer createFoodAnimation(Canvas canvas) {
		
		canvas.setVisible(true);
		
		AnimationTimer animation = new AnimationTimer() {

			@Override
			public void handle(long now) {

				if (canvas.getTranslateY() > (root.getHeight() - 50)) {
					this.stop();
					root.getChildren().remove(canvas);
				}

				double foodY = canvas.getLayoutY() + canvas.getTranslateY();

				if ((foodY + FOOD_HEIGHT) > fish1Canvas.getLayoutY() && foodY < (FISH_HEIGHT  + fish1Canvas.getLayoutY())) {

					System.out.println("Inside first if");

					double fishX = fish1Canvas.getLayoutX() + fish1Canvas.getTranslateX();
					System.out.println(fishX);
					System.out.println("canvas1.getTranslateX() - " + fish1Canvas.getLayoutX());
					System.out.println("canvas1.getTranslateX() + 100 - " + (100 + fish1Canvas.getLayoutX()));

					if ((fishX + FISH_WIDTH) > (canvas.getLayoutX())
							&& (fishX) < (canvas.getLayoutX() + canvas.getWidth())) {
						System.out.println("Inside 2nd if");
						this.stop();
						System.out.println("removing food");
						root.getChildren().remove(canvas);						
					}
				}
				
				if ((foodY + FOOD_HEIGHT) > redFishCanvas.getLayoutY() && foodY < (FISH_HEIGHT  + redFishCanvas.getLayoutY())) {
					System.out.println("Inside first if");
					double fishX = redFishCanvas.getLayoutX() + redFishCanvas.getTranslateX();
					System.out.println(fishX);
					System.out.println("canvas1.getTranslateX() - " + redFishCanvas.getLayoutX());
					System.out.println("canvas1.getTranslateX() + 100 - " + (100 + redFishCanvas.getLayoutX()));

					if ((fishX + FISH_WIDTH) > (canvas.getLayoutX())
							&& (fishX) < (canvas.getLayoutX() + canvas.getWidth())) {
						System.out.println("Inside 2nd if");
						this.stop();
						System.out.println("removing food");
						root.getChildren().remove(canvas);						
					}
				}
				
				if ((foodY + FOOD_HEIGHT) > crabFishCanvas.getLayoutY() && foodY < (FISH_HEIGHT  + crabFishCanvas.getLayoutY())) {
					System.out.println("Inside first if");
					double fishX = crabFishCanvas.getLayoutX() + crabFishCanvas.getTranslateX();
					System.out.println(fishX);
					System.out.println("canvas1.getTranslateX() - " + crabFishCanvas.getLayoutX());
					System.out.println("canvas1.getTranslateX() + 100 - " + (100 + crabFishCanvas.getLayoutX()));

					if ((fishX + FISH_WIDTH) > (canvas.getLayoutX())
							&& (fishX) < (canvas.getLayoutX() + canvas.getWidth())) {
						System.out.println("Inside 2nd if");
						this.stop();
						System.out.println("removing food");
						root.getChildren().remove(canvas);						
					}
				}

				canvas.setTranslateY(canvas.getTranslateY() + 1);				
			}
		};
		
		return animation;
	}
	
	private final int SHELL_X = 350;
	
	public void createShell() {
		
		Image img = new Image(new File("shell.png").toURI().toString(), FISH_WIDTH, FISH_HEIGHT, false, false);
		
		shellCanvas1 = new Canvas(FISH_WIDTH, FISH_HEIGHT);		
		ShellObject shellObject1 = new ShellObject(img, shellCanvas1.getGraphicsContext2D(), 0, 0);
		shellObject1.update();		
		shellCanvas1.setLayoutX(SHELL_X);
		shellCanvas1.setLayoutY(75);	
		shellCanvas1.setVisible(false);
		
		shellCanvas2 = new Canvas(FISH_WIDTH, FISH_HEIGHT);		
		ShellObject shellObject2 = new ShellObject(img, shellCanvas2.getGraphicsContext2D(), 0, 0);
		shellObject2.update();		
		shellCanvas2.setLayoutX(SHELL_X);
		shellCanvas2.setLayoutY(200);	
		shellCanvas2.setVisible(false);
		
		shellCanvas3 = new Canvas(FISH_WIDTH, FISH_HEIGHT);		
		ShellObject shellObject3 = new ShellObject(img, shellCanvas3.getGraphicsContext2D(), 0, 0);
		shellObject3.update();		
		shellCanvas3.setLayoutX(SHELL_X);
		shellCanvas3.setLayoutY(400);	
		shellCanvas3.setVisible(false);
		
		root.getChildren().addAll(shellCanvas1, shellCanvas2, shellCanvas3);
		
		
									
	}
	
	/**
	 * Create animation for sleep
	 * @param canvas
	 */
	public void createShellAnimation(Canvas canvas) {
		
		TranslateTransition translate = new TranslateTransition();
		
		double dist = SHELL_X - canvas.getTranslateX();
		
		System.out.println(dist);
		
		translate.setDuration(Duration.millis(1000));
		
		translate.setByX(dist); 
		
		translate.setNode(canvas);  
		
		translate.play();		
		
		translate.setOnFinished(e -> {
			canvas.setVisible(false);
		});
		
	}
	
}
