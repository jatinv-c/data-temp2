package pro.Aquarium;

import java.io.File;

import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;

public class Singleton {

	private static Singleton singleton;
	
	private final int FOOD_HEIGHT = 50;
	private final int FOOD_WIDTH = 50;
	
	private int[] foodXArr = {250, 450};
	
	Image foodImg = new Image(new File("food.png").toURI().toString(), FOOD_WIDTH, FOOD_HEIGHT, false, false);
	
	private Singleton() {		
	}
	
	//get the single instance of singleton class
    public static Singleton getInstance() {
        //create the instance if it is null. FIrst time whenever this method is called
        if (singleton == null) {
            singleton = new Singleton();
        }
        return singleton;
    }
	
    /**
     * Create and return a canvas object which contains food image
     * @return
     */
	public Canvas getNewFoodObject() {
		Canvas canvas = new Canvas(FOOD_WIDTH, FOOD_HEIGHT);		
		FoodObject foodObject = new FoodObject(foodImg, canvas.getGraphicsContext2D(), 0, 0);
		foodObject.update();
		return canvas;
	}
	
	/**
	 * Method to get x cordinate for Food
	 * @return
	 */
	public int[] getFoodXArr() {
		return foodXArr;
	}
}
