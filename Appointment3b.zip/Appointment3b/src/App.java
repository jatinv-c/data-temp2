import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.time.LocalDateTime;

public class App extends Application {

    /**
     * This function is called when the FXML app starts
     *
     * @param stage Primary stage
     * @throws Exception throws Exception
     */
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("view/Login.fxml"));

        LocalDateTime now = LocalDateTime.now();

        Scene scene = new Scene(root);

        stage.setScene(scene);
        stage.show();
    }

    /**
     * Main method of the application - starting point
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
