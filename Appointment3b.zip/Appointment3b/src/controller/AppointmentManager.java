package controller;

import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;
import model.Appointment;
import model.Contact;
import model.Customer;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.chrono.ChronoLocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.Temporal;
import java.time.temporal.TemporalAccessor;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

/**
 *
 * This Class has functionality which user use to schedule/modify/delete
 * appointments
 */
public class AppointmentManager implements Initializable {


    @FXML
    private TableView<Appointment> appointmentTableView;
    @FXML
    private Button addButton, modifyButton, deleteButton, backButton;
    @FXML
    private ComboBox<String> contactComboBox, typeComboBox;
    @FXML
    private RadioButton allAppointRadio, weeklyAppointRadio, monthlyAppointRadio;
    @FXML
    private TextField appointIdText, titleText, locationText, startDateText, endDateText,
            customerIDText, userIDText, descText;
    @FXML
    private Label scheduleLabel, contNameLabel, appointIdLabel, titleLabel, descLabel, locationLabel,
            typeLabel, startDateLabel, endDateLabel, cusIdLabel, userIdLabel, filterLabel;
    @FXML
    private TableColumn<Appointment, String> contactName, appointmentIDCol, title,
            description, location, type, customerID, userID;

    @FXML
    private TableColumn<Appointment, LocalDateTime> startDate, endDate;

            Alert popUpDialog;

    ArrayList<Customer> customerArrayList = new ArrayList<>();
    ArrayList<Contact> contactArrayList = new ArrayList<>();

    boolean checkBool;
    boolean modifyBool = false;

    String language, ID, emptyMessage, hourErrorMessage, successMessage,
            IDErrorMessage, dateErrorMessage,outBusinessHourErrorMessage, appointIDErrorMessage, ErrorMessage;

    DateTimeFormatter sdf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public ZoneId zone = ZoneId.systemDefault();


    /**
     * This method  initialize all the values
     *
     * @param url - url
     * @param rb - any resource bundles such as language, etc
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        contactComboBox.getItems().clear();
        customerArrayList = Database.getCustData();
        contactArrayList = Database.getContactsDetails();
        checkBool = false;
        popUpDialog = new Alert(Alert.AlertType.INFORMATION);

        //setting table view column properties
        contactName.setCellValueFactory(new PropertyValueFactory<>("contactID"));
        appointmentIDCol.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        title.setCellValueFactory(new PropertyValueFactory<>("title"));
        description.setCellValueFactory(new PropertyValueFactory<>("description"));
        location.setCellValueFactory(new PropertyValueFactory<>("location"));

        type.setCellValueFactory(new PropertyValueFactory<>("type"));
        startDate.setCellValueFactory(new PropertyValueFactory<>("startDate"));
        startDate.setCellFactory(new ColumnFormatter<Appointment, LocalDateTime>(sdf));
        endDate.setCellValueFactory(new PropertyValueFactory<>("endDate"));
        endDate.setCellFactory(new ColumnFormatter<Appointment, LocalDateTime>(sdf));
        customerID.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        userID.setCellValueFactory(new PropertyValueFactory<>("userID"));
        //show appointment details in tableView
        showData();
        //userIDText.setEditable(false);
        appointIdText.setText(new Random().nextInt(2000) + "");
        appointIdText.setEditable(false);

    }

    /**
     * This method sets values of user data in the ui window
     *
     * @param language selected language
     */
    public void setUserData(String language) {
        this.language = language;
        userIDText.setText("");
        if (language.equals("French")) {
            scheduleLabel.setText("Rendez-vous");

            contNameLabel.setText("Nom du contact");
            appointIdLabel.setText("ID de rendez-vous");
            titleLabel.setText("Titre");
            descLabel.setText("La description");
            locationLabel.setText("emplacement");
            typeLabel.setText("Taper");
            startDateLabel.setText("Date de début");
            endDateLabel.setText("date de fin");
            cusIdLabel.setText("identité du client");
            userIdLabel.setText("Identifiant d'utilisateur");

            addButton.setText("ajouter");
            modifyButton.setText("modifier");
            deleteButton.setText("effacer");
            backButton.setText("Arrière");

            weeklyAppointRadio.setText("hebdomadaire");
            monthlyAppointRadio.setText("mensuel");
            allAppointRadio.setText("tous les rendez-vous");
            filterLabel.setText("filtrer par");
            contactComboBox.getItems().add("sélectionner");
            typeComboBox.getItems().add("sélectionner");
            emptyMessage = "Erreur. Aucun champ ne peut être vide";
            hourErrorMessage = "Erreur. Les heures de travail sont de 08h00 à 22h00";
            successMessage = "Succès";
            IDErrorMessage = "Mauvais identifiant client ! Veuillez saisir l'ID correct !";
            dateErrorMessage = "Veuillez utiliser le format yyyy:MM:dd hh:mm:ss pour la date et l'heure";
            outBusinessHourErrorMessage = "Veuillez entrer des dates de travail pour le rendez-vous svp.";
            appointIDErrorMessage = "L'ID de rendez-vous ne peut pas être vide !";
            ErrorMessage = "Aucun rendez-vous trouvé avec cet ID";

        } else {
            contactComboBox.getItems().add("Select Contact");
            typeComboBox.getItems().add("Select Type ");
            emptyMessage = "Error. No field can be empty";
            hourErrorMessage = "Error. Working Hours are 08:00 am to 10:00 pm";
            successMessage = "Success";
            IDErrorMessage = "Wrong Customer ID! Please Enter Correct ID!";
            dateErrorMessage = "Please Use yyyy:MM:dd hh:mm:Ss format for Date & Time";
            outBusinessHourErrorMessage = "Please enter dates in Business Hours for the appoointement";
            appointIDErrorMessage = "Appointment ID can't be empty!";
            ErrorMessage = "No Appointment found with this ID";
        }
        contactComboBox.getSelectionModel().select(0);
        typeComboBox.getSelectionModel().select(0);
        for (Contact contact : contactArrayList) {
            contactComboBox.getItems().add(contact.getContactID());
        }
        typeComboBox.getItems().add("Software Review");
        typeComboBox.getItems().add("Software Documentation");
        typeComboBox.getItems().add("Software Revision");
        typeComboBox.getItems().add("Software Update");
    }


    /**
     * This method add the record of appointment in
     * MySql database
     *
     * @param event - event
     */
    @FXML
    private void addAppointment(ActionEvent event) {


        //condition to check if all field are empty or not
        if (typeComboBox.getSelectionModel().getSelectedIndex() == -1 || appointIdText.getText().isEmpty() || startDateText.getText().isEmpty()
                || titleText.getText().isEmpty() || endDateText.getText().isEmpty()
                || descText.getText().isEmpty() || customerIDText.getText().isEmpty()
                || locationText.getText().isEmpty() || userIDText.getText().isEmpty()
                || contactComboBox.getSelectionModel().getSelectedIndex() == -1 || contactComboBox.getSelectionModel().getSelectedIndex() == 0) {
            //display error message
            new Alert(Alert.AlertType.ERROR, emptyMessage).showAndWait();

        } else {

            //to validate date
            String format = "[0-9]{4}[-]{1}[0-9]{2}[-]{1}[0-9]{2}[ ]{1}[0-9]{2}[:]{1}[0-9]{2}[:]{1}[0-9]{2}";
            //checking date field
            if (Pattern.matches(format, startDateText.getText()) && Pattern.matches(format, endDateText.getText())) {
                boolean flag = false;
                for (Customer customer : customerArrayList) {
                    if (customer.getCustomerID().equals(customerIDText.getText())) {
                        flag = true;
                    }
                }

                if (flag) {

                    if (modifyBool) {
                        new Alert(Alert.AlertType.INFORMATION, "Please click modify button to modify results").showAndWait();

                    } else {
                        //appointment object to add value in database
                        Appointment appointment = null;

                        LocalDateTime startdate_value = LocalDateTime.parse(startDateText.getText(), sdf);
                        LocalDateTime enddate_value = LocalDateTime.parse(endDateText.getText(), sdf);

                        //check if we are in business hours
                        if (inBusinessHours(startdate_value) && inBusinessHours(enddate_value)) {

                            appointment = new Appointment(contactComboBox.getSelectionModel().getSelectedItem(), appointIdText.getText(), titleText.getText(), descText.getText(), locationText.getText(), typeComboBox.getSelectionModel().getSelectedItem(),
                                    startdate_value, enddate_value, customerIDText.getText(), userIDText.getText());

                            //using to add appointment detail in database
                            String createdBy = "";
                            for (User user : Database.getUsersData()) {
                                if (user.getUserID().equals(userIDText)) {
                                    createdBy = user.getUserName();
                                }
                            }

                            Date date = new Date();
                            SimpleDateFormat ft1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:hh");
                            String time = ft1.format(date);

                            Database.addAppointment(appointment, time, createdBy, time, createdBy);
                            //display message information
                            new Alert(Alert.AlertType.INFORMATION, successMessage).showAndWait();
                            //reset values to default values
                            appointIdText.setText(new Random().nextInt(2000) + "");

                            titleText.setText("");
                            descText.setText("");
                            locationText.setText("");

                            startDateText.setText("");
                            endDateText.setText("");
                            customerIDText.setText("");

                            showData();
                        } else {
                            // show message out of business hours
                            new Alert(Alert.AlertType.ERROR, outBusinessHourErrorMessage).showAndWait();

                        }
                    }

                } else {
                    //display error message
                    new Alert(Alert.AlertType.ERROR, IDErrorMessage).showAndWait();
                }
            } else {
                //display date&time format error message
                new Alert(Alert.AlertType.ERROR, dateErrorMessage).showAndWait();
            }

        }
    }

    /**
     * This method is used to delete appointment Record
     *
     * @param event event
     */
    @FXML
    private void deleteAppointment(ActionEvent event) {

        //condition to check if appointment id is empty
        if (appointmentTableView.getSelectionModel().getSelectedIndex() == -1) {
            //display error message
            new Alert(Alert.AlertType.ERROR, appointIDErrorMessage).showAndWait();
        } else {
            Appointment ap = appointmentTableView.getSelectionModel().getSelectedItem();
            //using method to delete record in dataabse
            Database.deleteAppointment(ap.getAppointmentID());
            //display message information
            new Alert(Alert.AlertType.INFORMATION, successDeleteAppointmentMessage(ap)).showAndWait();
            appointIdText.setText("");
            showData();     //update details in tableView
            appointIdText.setText(new Random().nextInt(2000) + "");

        }
    }

    /**
     * This method is used to create and get successful deletion message
     *
     * @param ap - Appointment object
     * @return String containing success message
     */
    private String successDeleteAppointmentMessage(Appointment ap) {
        String message = "";
        if (language.equals("French")) {
            message = "Le Rendz-vous #" + ap.getAppointmentID() + " ("
                    + ap.getType() + ")\n est supprimé avec succès.";
        } else {
            message = "Appointment #" + ap.getAppointmentID() + " ("
                    + ap.getType() + ")\n is deleted successfully.";
        }

        return message;
    }

    /**
     * This method to updated appointment record in database
     * and shows updated data in table
     *
     * @param event event
     */
    @FXML
    private void updateRecord(ActionEvent event) {

        Appointment ap = null;
        //using condition check
        if (checkBool) {
            Customer cs = Database.getCustomerData(customerIDText.getText());
            if (cs != null) {
                if (typeComboBox.getSelectionModel().getSelectedIndex() == -1 || appointIdText.getText().isEmpty() || startDateText.getText().isEmpty()
                        || titleText.getText().isEmpty() || endDateText.getText().isEmpty()
                        || descText.getText().isEmpty() || customerIDText.getText().isEmpty()
                        || locationText.getText().isEmpty() || userIDText.getText().isEmpty() || userIDText.getText().isEmpty()
                        || contactComboBox.getSelectionModel().getSelectedIndex() == -1 || contactComboBox.getSelectionModel().getSelectedIndex() == 0) {
                    //display error message
                    new Alert(Alert.AlertType.ERROR, emptyMessage).showAndWait();

                } else {
                    //creating appointment object to update values
                    Appointment appointment = null;

                    LocalDateTime startDate_value = LocalDateTime.parse(startDateText.getText(), sdf);
                    LocalDateTime endDate_value = LocalDateTime.parse(endDateText.getText(), sdf);

                    if (inBusinessHours(startDate_value) && inBusinessHours(endDate_value)) {
                    appointment = new Appointment(contactComboBox.getSelectionModel().getSelectedItem(), appointIdText.getText(), titleText.getText(), descText.getText(), locationText.getText(), typeComboBox.getSelectionModel().getSelectedItem(),
                            startDate_value, endDate_value, customerIDText.getText(), userIDText.getText());

                    //using method to update record in database
                    Date date = new Date();
                    SimpleDateFormat ft1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:hh");
                    String time = ft1.format(date);
                    String updatedBy = "";
                    for (User user : Database.getUsersData()) {
                        if (user.getUserID().equals(userIDText)) {
                            updatedBy = user.getUserName();
                        }
                    }

                    Database.editAppointment(appointment, time, updatedBy);
                    //display message information
                    new Alert(Alert.AlertType.INFORMATION, successMessage).showAndWait();
                    //reset attribute fields to by default values
                    checkBool = false;
                    appointIdText.setText(new Random().nextInt(2000) + "");

                    titleText.setText("");
                    descText.setText("");
                    locationText.setText("");

                    startDateText.setText("");
                    userIDText.setText("");
                    endDateText.setText("");
                    customerIDText.setText("");

                    customerIDText.setEditable(true);

                    showData();
                    modifyBool = false;
                } else {
                        new Alert(Alert.AlertType.ERROR, outBusinessHourErrorMessage).showAndWait();
                    }
                }
            }  else {
                new Alert(Alert.AlertType.ERROR, IDErrorMessage).showAndWait();
            }

        } else {
            if (appointmentTableView.getSelectionModel().getSelectedIndex() == -1) {
                //display error message
                new Alert(Alert.AlertType.ERROR, emptyMessage).showAndWait();
            } else {
                Appointment appointment = appointmentTableView.getSelectionModel().getSelectedItem();
                if (appointment != null) {
                    appointIdText.setText(appointment.getAppointmentID());
                    contactComboBox.getSelectionModel().select(appointment.getContactID());
                    titleText.setText(appointment.getTitle());
                    descText.setText(appointment.getDescription());
                    locationText.setText(appointment.getLocation());

                    typeComboBox.getSelectionModel().select(appointment.getType());
                    startDateText.setText(sdf.format(appointment.getStartDate()));
                    endDateText.setText(sdf.format(appointment.getEndDate()));
                    customerIDText.setText(appointment.getCustomerID());
                    userIDText.setText(appointment.getUserID());

                    checkBool = true;
                    modifyBool =true;

                } else {
                    new Alert(Alert.AlertType.ERROR, ErrorMessage).showAndWait();
                }
            }
        }
    }

    /**
     * This method show appointment details in table
     */
    public void showData() {
        try {
            appointmentTableView.setItems(showAllAppointment());
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     * This method is to filter monthly appointments
     *
     * @return appointments
     * @throws SQLException throw exception
     */
    public ObservableList<Appointment> monthlyAppointments() throws SQLException {
        Date date = new Date();
        SimpleDateFormat ft1 = new SimpleDateFormat("MM");
        String month = ft1.format(date);
        ArrayList<Appointment> cs = Database.getappointmentDetails();
        ArrayList<Appointment> ap = new ArrayList<>();
        for (Appointment c : cs) {
            String m = ft1.format(c.getStartDate());
            if (m.equals(month)) {
                ap.add(c);
            }
            /*
            String sD[] = c.getStartDate().split(" ");
            String a[] = sD[0].split("-");

            if (a[1].equals(month)) {
                ap.add(c);
            }

             */
        }
        ObservableList<Appointment> cst = FXCollections.observableArrayList();

        for (Appointment appointment : ap) {
            cst.add(appointment);
        }

        return cst;
    }

    /**
     * This method is to filter weekly appointments
     *
     * @return appointments
     * @throws SQLException throws exception
     */
    public ObservableList<Appointment> showWeeklyAppointments() throws SQLException {
        Date date = new Date();
        SimpleDateFormat ft1 = new SimpleDateFormat("dd");
        String day = ft1.format(date);

        ArrayList<Appointment> cs = Database.getappointmentDetails();
        ArrayList<Appointment> ap = new ArrayList<>();
        int prevDate;
        int prevMonth = 0;
        String month;
        Date date1 = new Date();
        month = ft1.format(date1);
        SimpleDateFormat ft11 = new SimpleDateFormat("MM");
        month = ft1.format(date1);
        if ((Integer.parseInt(day) - 7) > 0) {
            prevDate = Integer.parseInt(day) - 7;

        } else {

            prevMonth = Integer.parseInt(month) - 1;

            if (prevMonth == 2) {
                prevDate = (Integer.parseInt(day) - 7) + 28;
            } else {
                if (prevMonth == 1 || prevMonth == 3 || prevMonth == 5 || prevMonth == 7 || prevMonth == 8 || prevMonth == 10 || prevMonth == 12) {
                    prevDate = (Integer.parseInt(day) - 7) + 31;
                } else {
                    prevDate = (Integer.parseInt(day) - 7) + 30;
                }
            }

        }
        prevDate = prevDate + 1;

        for (Appointment c : cs) {
            String[] sD = sdf.format(c.getStartDate()).split(" ");

            String[] a = sD[0].split("-");

            if (prevMonth == 0) {
                Date dt = new Date();

                SimpleDateFormat f = new SimpleDateFormat("MM");
                String m = f.format(dt);

                int calendarDate = Integer.parseInt(a[2]);
                int currentDay = Integer.parseInt(day);
                int calendarMonth = Integer.parseInt(a[1]);
                int currentMonth = Integer.parseInt(m);

                if ((calendarDate >= prevDate && calendarDate <= currentDay) && calendarMonth == currentMonth) {
                    ap.add(c);
                }
            } else {
                if ((Integer.parseInt(a[1]) == Integer.parseInt(month) && Integer.parseInt(a[0]) <= Integer.parseInt(day)) || (prevMonth == Integer.parseInt(a[1]) && Integer.parseInt(a[2]) >= prevDate)) {
                    ap.add(c);

                }
            }

        }
        ObservableList<Appointment> cst = FXCollections.observableArrayList();
        for (Appointment c : ap) {
            cst.add(c);
        }
        return cst;
    }


    /**
     *  This method shows all scheduled appointments
     *
     * @return - An observable list of all the appointments found
     * @throws SQLException might throw SQL Exception
     */
    public ObservableList<Appointment> showAllAppointment() throws SQLException {
        ArrayList<Appointment> cs = Database.getappointmentDetails();
        ObservableList<Appointment> cst = FXCollections.observableArrayList();
        for (Appointment c : cs) {
            cst.add(c);
        }
        return cst;
    }

    /**
     * This method filters appointments by week and shows in table
     *
     * @param event event
     */
    @FXML
    private void showWeeklyAppointments(ActionEvent event) {
        //display weekly appointments in tableView
        try {
            appointmentTableView.setItems(showWeeklyAppointments());
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     * This method filters and shows appointments by month
     *
     * @param event event
     */
    @FXML
    private void showMonthlyAppointments(ActionEvent event) {
        try {
            appointmentTableView.setItems(monthlyAppointments());
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     * This method shows all the appointments in table
     *
     * @param event event
     */
    @FXML
    private void showAllAppointment(ActionEvent event) {
        showData();
    }

    /**
     * This method navigated user back to main menu screen
     *
     * @param event event
     */
    @FXML
    private void gotoHomeScreen(ActionEvent event) {
        try {
            FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/view/MainMenu.fxml"));
            Parent root = fXMLLoader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Main Menu");
            Scene scene = new Scene(root);
            stage.setScene(scene);
            MainMenu controller = fXMLLoader.getController();
            controller.initiallizeData(ID, true, language);
            stage.show();
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    /**
     * method to check if a date is within a range of two dates
     * @param toCheck Date to check
     * @param startInterval start interval date
     * @param endInterval end interval date
     * @return true if the specified date falls between start and end date and false otherwise
     */
    public boolean within(LocalDateTime toCheck, LocalDateTime startInterval,
                          LocalDateTime endInterval) {
        return toCheck.compareTo(startInterval) >= 0 && toCheck.compareTo(endInterval) <= 0;
    }

    /**
     * This method checks if a date is in business hours.
     *
     * @param toCheck date to check
     * @return true if the given date falls between the business hours and false otherwise
     */
    public boolean inBusinessHours(LocalDateTime toCheck) {
        LocalDateTime startInterval = LocalDateTime.of(toCheck.toLocalDate(), LocalTime.of(8, 0, 0));
        LocalDateTime endInterval = LocalDateTime.of(toCheck.toLocalDate(), LocalTime.of(22, 0, 0));

        return within(toCheck, startInterval, endInterval);
    }

}

/**
 * Custom class to format TableCells
 * @param <S> Object
 * @param <T> Object
 */
class ColumnFormatter<S, T> implements Callback<TableColumn<S, T>, TableCell<S, T>> {
    private final DateTimeFormatter format;

    public ColumnFormatter(DateTimeFormatter format) {
        super();
        this.format = format;
    }
    @Override
    public TableCell<S, T> call(TableColumn<S, T> arg0) {
        return new TableCell<S, T>() {
            @Override
            protected void updateItem(T item, boolean empty) {
                super.updateItem(item, empty);
                if (item == null || empty) {
                    setGraphic(null);
                } else {
                    setGraphic(new Label(format.format((TemporalAccessor) item)));
                }
            }
        };
    }


}