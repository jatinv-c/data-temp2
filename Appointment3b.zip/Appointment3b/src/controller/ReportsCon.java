package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Appointment;
import model.AppointmentDetails;
import model.Contact;

/**
 * Appointment ReportsCon Controller class
 *
 * This Class have functionality to display Appointment ReportsCon by different
 * ways
 */
public class ReportsCon implements Initializable {

    @FXML
    private Button btn;
    @FXML
    private Label h1, h2,h3, h5, h6, h4;
    @FXML
    private ComboBox<String> contactCombo;
    @FXML
    private TableView<AppointmentDetails> tableContactSchedule;
    @FXML
    private TableView<model.Reports> tableAppointmentType, tableAppointmentMonth, tableCustomerMonth;
    @FXML
    private TableColumn<AppointmentDetails, String> appointmentIDCol, titleCol, typeCol, descriptionCol, startDateCol, endDateCol, customerIDCol;
    @FXML
    private TableColumn<model.Reports, String> typeCol1, numCol1, serialCol1, serialCol2, monthCol2, numCol2, serialCol3, monthCol3, numCol3;

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

    String id, language;
    ArrayList<Contact> contacts;
    ArrayList<Appointment> appointments;

    /**
     * Initializes the controller class.
     *
     * @param url url
     * @param rb Resource Bundle
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        appointments = new ArrayList<>();
        appointmentIDCol.setCellValueFactory(new PropertyValueFactory<>("appointmentID"));
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        typeCol.setCellValueFactory(new PropertyValueFactory<>("type"));
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        startDateCol.setCellValueFactory(new PropertyValueFactory<>("startDate"));
        endDateCol.setCellValueFactory(new PropertyValueFactory<>("endDate"));
        customerIDCol.setCellValueFactory(new PropertyValueFactory<>("customerID"));

        contacts = new ArrayList<>();
        contacts = Database.getContactsDetails();

        serialCol1.setCellValueFactory(new PropertyValueFactory<>("str1"));
        typeCol1.setCellValueFactory(new PropertyValueFactory<>("str2"));
        numCol1.setCellValueFactory(new PropertyValueFactory<>("str3"));

        serialCol2.setCellValueFactory(new PropertyValueFactory<>("str1"));
        monthCol2.setCellValueFactory(new PropertyValueFactory<>("str2"));
        numCol2.setCellValueFactory(new PropertyValueFactory<>("str3"));

        serialCol3.setCellValueFactory(new PropertyValueFactory<>("str1"));
        monthCol3.setCellValueFactory(new PropertyValueFactory<>("str2"));
        numCol3.setCellValueFactory(new PropertyValueFactory<>("str3"));

        try {
            displayAppointmentsByTypes();
            displayAppointmentsByMonth();
            displayCustomersByMonth();
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    /**
     * Initialize User ID
     *
     * @param id id
     * @param language language selceted
     */
    public void initializeData(String id, String language) {
        this.id = id;
        this.language = language;

        if (language.equals("French")) {
            contactCombo.getItems().add("Sélectionnez Combo");
            h1.setText("Rapports");
            h2.setText("nombre de rendez-vous par type");
            h3.setText("nombre de rendez-vous par mois");
            h4.setText("Nombre total de clients par mois");
            h5.setText("Calendrier de rendez-vous par nom de contact");
            h6.setText("Nom");
            btn.setText("Arrière");
        } else {

            contactCombo.getItems().add("Select Contact");
        }
        contactCombo.getSelectionModel().select(0);
        for (Contact contact : contacts) {
            contactCombo.getItems().add(contact.getContactID() + ":" + contact.getContactName());
        }

    }

    /**
     * This method add the appointment by contact name filter in observablelist
     * and adds data in table
     *
     * @param contactName contactName
     * @throws SQLException it throws exception
     */
    public void addByName(String contactName) throws SQLException {
        ArrayList<Appointment> cs = Database.getappointmentDetails();
        ArrayList<AppointmentDetails> ap = new ArrayList<>();
        String[] cntctName = contactName.split(":");
        for (Appointment appointment : cs) {

            if (cntctName[0].equals(appointment.getContactID())) {
                ap.add(new AppointmentDetails(appointment.getAppointmentID(), appointment.getTitle(), appointment.getDescription(), appointment.getType(), Timestamp.valueOf(appointment.getStartDate()), Timestamp.valueOf(appointment.getEndDate()), appointment.getCustomerID()));

            }
        }
        ObservableList<AppointmentDetails> cst = FXCollections.observableArrayList();
        for (AppointmentDetails appointmentDetails : ap) {
            cst.add(appointmentDetails);
        }

        try {
            tableContactSchedule.setItems(cst);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     * Whenever user selects any contact, this method add appointments in table
     * having this contact name
     *
     * @param event event
     */
    @FXML
    private void selectContact(ActionEvent event) {
        try {

            addByName(contactCombo.getSelectionModel().getSelectedItem());
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     * This method filters the appointments by month and shows in table
     *
     * @throws SQLException throw Exception
     */
    public void displayAppointmentsByMonth() throws SQLException {
        appointments = Database.getappointmentDetails();
        int jan = 0;
        int feb = 0;
        int march = 0;
        int april = 0;
        int may = 0;
        int jun = 0;
        int july = 0;
        int august = 0;
        int sep = 0;
        int oct = 0;
        int nov = 0;
        int dec = 0;

        String[] a;
        String[] b;
        for (Appointment appointment : appointments) {
            a = sdf.format(appointment.getStartDate()).split(" ");
            b = a[0].split("-");
            if (Integer.parseInt(b[1]) == 01) {
                jan++;
            }
            if (Integer.parseInt(b[1]) == 02) {
                feb++;
            }
            if (Integer.parseInt(b[1]) == 03) {
                march++;
            }
            if (Integer.parseInt(b[1]) == 04) {
                april++;
            }
            if (Integer.parseInt(b[1]) == 05) {
                may++;
            }
            if (Integer.parseInt(b[1]) == 06) {
                jun++;
            }
            if (Integer.parseInt(b[1]) == 07) {
                july++;
            }

            if (Integer.parseInt(b[1]) == 8) {
                july++;
            }

            if (Integer.parseInt(b[1]) == 9) {
                sep++;
            }
            if (Integer.parseInt(b[1]) == 10) {
                oct++;
            }
            if (Integer.parseInt(b[1]) == 11) {
                nov++;
            }
            if (Integer.parseInt(b[1]) == 12) {
                dec++;
            }
        }

        ArrayList<model.Reports> reports = new ArrayList<>();
        int counter = 1;
        if (jan != 0) {
            reports.add(new model.Reports(counter + "", "January", jan + ""));
            counter++;
        }
        if (feb != 0) {
            reports.add(new model.Reports(counter + "", "February", feb + ""));
            counter++;
        }
        if (march != 0) {
            reports.add(new model.Reports(counter + "", "March", march + ""));
            counter++;
        }
        if (april != 0) {
            reports.add(new model.Reports(counter + "", "April", april + ""));
            counter++;
        }
        if (may != 0) {
            reports.add(new model.Reports(counter + "", "May", may + ""));
            counter++;
        }
        if (jun != 0) {
            reports.add(new model.Reports(counter + "", "Jun", jun + ""));
            counter++;
        }
        if (july != 0) {
            reports.add(new model.Reports(counter + "", "July", july + ""));
            counter++;
        }
        if (august != 0) {
            reports.add(new model.Reports(counter + "", "August", august + ""));
            counter++;
        }
        if (sep != 0) {
            reports.add(new model.Reports(counter + "", "September", sep + ""));
            counter++;
        }
        if (oct != 0) {
            reports.add(new model.Reports(counter + "", "October", oct + ""));
            counter++;
        }
        if (nov != 0) {
            reports.add(new model.Reports(counter + "", "November", nov + ""));
            counter++;
        }
        if (dec != 0) {
            reports.add(new model.Reports(counter + "", "Descember", dec + ""));
            counter++;
        }


        ObservableList<model.Reports> cst = FXCollections.observableArrayList();
        for (model.Reports r : reports) {
            cst.add(r);
        }

        try {
            tableAppointmentMonth.setItems(cst);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     * This method filters the customers record by month and shows in table
     *
     * @throws SQLException throw Exception
     */
    public void displayCustomersByMonth() throws SQLException {
        ArrayList<String> customers = Database.getCustomerReport();
        int jan = 0;
        int feb = 0;
        int march = 0;
        int april = 0;
        int may = 0;
        int jun = 0;
        int july = 0;
        int august = 0;
        int sep = 0;
        int oct = 0;
        int nov = 0;
        int dec = 0;

        String[] b;
        for (String str : customers) {
            b = str.split("-");
            if (Integer.parseInt(b[1]) == 01) {
                jan++;
            }
            if (Integer.parseInt(b[1]) == 02) {
                feb++;
            }
            if (Integer.parseInt(b[1]) == 03) {
                march++;
            }
            if (Integer.parseInt(b[1]) == 04) {
                april++;
            }
            if (Integer.parseInt(b[1]) == 05) {
                may++;
            }
            if (Integer.parseInt(b[1]) == 06) {
                jun++;
            }
            if (Integer.parseInt(b[1]) == 07) {
                july++;
            }

            if (Integer.parseInt(b[1]) == 8) {
                july++;
            }

            if (Integer.parseInt(b[1]) == 9) {
                sep++;
            }
            if (Integer.parseInt(b[1]) == 10) {
                oct++;
            }
            if (Integer.parseInt(b[1]) == 11) {
                nov++;
            }
            if (Integer.parseInt(b[1]) == 12) {
                dec++;
            }
        }

        ArrayList<model.Reports> reports = new ArrayList<>();
        int counter = 1;
        if (jan != 0) {
            reports.add(new model.Reports(counter + "", "January", jan + ""));
            counter++;
        }
        if (feb != 0) {
            reports.add(new model.Reports(counter + "", "February", feb + ""));
            counter++;
        }
        if (march != 0) {
            reports.add(new model.Reports(counter + "", "March", march + ""));
            counter++;
        }
        if (april != 0) {
            reports.add(new model.Reports(counter + "", "April", april + ""));
            counter++;
        }
        if (may != 0) {
            reports.add(new model.Reports(counter + "", "May", may + ""));
            counter++;
        }
        if (jun != 0) {
            reports.add(new model.Reports(counter + "", "Jun", jun + ""));
            counter++;
        }
        if (july != 0) {
            reports.add(new model.Reports(counter + "", "July", july + ""));
            counter++;
        }
        if (august != 0) {
            reports.add(new model.Reports(counter + "", "August", august + ""));
            counter++;
        }
        if (sep != 0) {
            reports.add(new model.Reports(counter + "", "September", sep + ""));
            counter++;
        }
        if (oct != 0) {
            reports.add(new model.Reports(counter + "", "October", oct + ""));
            counter++;
        }
        if (nov != 0) {
            reports.add(new model.Reports(counter + "", "November", nov + ""));
            counter++;
        }
        if (dec != 0) {
            reports.add(new model.Reports(counter + "", "Descember", dec + ""));
            counter++;
        }


        ObservableList<model.Reports> cst = FXCollections.observableArrayList();
        for (model.Reports r : reports) {
            cst.add(r);
        }

        try {
            tableCustomerMonth.setItems(cst);
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     * This method filters the appointments by their types and then shows in
     * table
     *
     * @throws SQLException throws Exception
     */
    public void displayAppointmentsByTypes() throws SQLException {

        ArrayList<Appointment> type1ArrayList = new ArrayList<>();
        ArrayList<Appointment> type2ArrayList = new ArrayList<>();
        ArrayList<Appointment> type3ArrayList = new ArrayList<>();
        ArrayList<Appointment> type4ArrayList = new ArrayList<>();

        appointments = Database.getappointmentDetails();

        for (Appointment appointment : appointments) {
            if (appointment.getType().equals("Software Review")) {
                type1ArrayList.add(appointment);
            }
            if (appointment.getType().equals("Software Documentation")) {
                type2ArrayList.add(appointment);
            }
            if (appointment.getType().equals("Software Revision")) {
                type3ArrayList.add(appointment);
            }
            if (appointment.getType().equals("Software Update")) {
                type4ArrayList.add(appointment);
            }

        }

        ArrayList<model.Reports> reportArrayList = new ArrayList<>();
        int counter = 1;
        if (type1ArrayList.size() != 0) {
            reportArrayList.add(new model.Reports(counter + "", "Software Review", type1ArrayList.size() + ""));
            counter++;
        }
        if (type2ArrayList.size() != 0) {
            reportArrayList.add(new model.Reports(counter + "", "Software Documentation", type2ArrayList.size() + ""));
            counter++;
        }
        if (type3ArrayList.size() != 0) {
            reportArrayList.add(new model.Reports(counter + "", "Software Revision", type3ArrayList.size() + ""));
            counter++;
        }
        if (type4ArrayList.size() != 0) {
            reportArrayList.add(new model.Reports(counter + "", "Software Update", type4ArrayList.size() + ""));
            counter++;
        }

        ObservableList<model.Reports> cst = FXCollections.observableArrayList();
        for (model.Reports r : reportArrayList) {
            cst.add(r);
        }

        try {
            tableAppointmentType.setItems(cst);
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    /**
     * This method navigates user back to main menu screen
     *
     * @param event Action event
     */
    @FXML
    private void navigateBack(ActionEvent event) {
        try {
            FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/view/MainMenu.fxml"));
            Parent root = fXMLLoader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Main Menu");
            Scene scene = new Scene(root);
            stage.setScene(scene);
            MainMenu controller = fXMLLoader.getController();
            controller.initiallizeData(id, true, language);
            stage.show();
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

}
