package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;
import java.util.ResourceBundle;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyCode;
import javafx.stage.Stage;
import model.Country;
import model.Customer;
import model.Division;
import model.User;

/**
 *
 * This Controller Class holds functionality which helps user to
 * add/modify/delete Customer Record
 */
public class CustomerManager implements Initializable {

    @FXML
    private TableView<Customer> table;
    @FXML
    private Button btn1, btn2, btn3,  btn4;
    @FXML
    private ComboBox<String> country, division;
    @FXML
    private TextField name, postalCode, phoneNumber, address, id;
    @FXML
    private Label h1,idLbl, nmLbl, pCodeLbl, pnumLbl, adLbl, cnLbl, divLbl;
    @FXML
    private TableColumn<Customer, String> customerIDCol, customerNameCol, postalCodeCol, phoneNumberCol, addressCol, countryCol, divisionCol;

    boolean check;
    boolean modify = false;
    String userID, language;
    ArrayList<Country> countries;
    ArrayList<Customer> customers;
    ArrayList<Division> divisions;
    String sMsg, emptyMsg, delMsg, delEmpMsg, upMsg, noMsg;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        //intialize database controller object
        countries = Database.getCountriesRecord();
        divisions = Database.getDivisionsRecord();
        check = false;
        //setting column properties of table view
        customerIDCol.setCellValueFactory(new PropertyValueFactory<>("customerID"));
        customerNameCol.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        postalCodeCol.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
        phoneNumberCol.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        addressCol.setCellValueFactory(new PropertyValueFactory<>("address"));
        countryCol.setCellValueFactory(new PropertyValueFactory<>("country"));
        divisionCol.setCellValueFactory(new PropertyValueFactory<>("division"));
        customers = Database.getCustData();      //getting available customers from database
        showCustomerData();         //adding customer data in table
        //adding countries in combo box

        id.setText(new Random().nextInt(3000) + "");
        id.setEditable(false);

        phoneNumber.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue,
                                String newValue) {
                if (!newValue.matches("\\d*")) {
                    phoneNumber.setText(newValue.replaceAll("[^\\d]", ""));
                }
            }
        });

        postalCode.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observable, String oldValue,
                                String newValue) {
                if (!newValue.matches("\\d*")) {
                    postalCode.setText(newValue.replaceAll("[^\\d]", ""));
                }
            }
        });

    }

    /**
     * This method is used to  set values to the UI elements
     *
     * @param id sets the value of user id
     * @param language sets the user language
     */
    public void setUserValues(String id, String language) {
        this.userID = id;
        this.language = language;
        if (language.equals("French")) {
            h1.setText("Fiche client");
            idLbl.setText("identifiant");
            nmLbl.setText("Nom du client");
            pCodeLbl.setText("code postal");
            pnumLbl.setText("Téléphoner#");
            adLbl.setText("Adresse");
            cnLbl.setText("Pays");
            divLbl.setText("Division de premier niveau");
            btn1.setText("ajouter");
            btn2.setText("modifier");
            btn3.setText("effacer");
            btn4.setText("Arrière");
            country.getItems().add("sélectionner");
            emptyMsg = "Erreur. Aucun champ ne peut être vide";
            sMsg = "Enregistrement enregistré avec succès dans la base de données !";
            delEmpMsg = "L'ID client ne peut pas être vide !";
            delMsg = "Enregistrement supprimé avec succès.";
            noMsg = "Aucun enregistrement client avec cet ID !";
            upMsg = "Mise à jour réussie";

        } else {
            country.getItems().add("Select from following");
            emptyMsg = "Error. No field can be empty";
            sMsg = "Record Successfully saved in database!";
            delEmpMsg = "Customer ID can't be empty!";
            delMsg = "Record Successfully Deleted.";
            noMsg = "No Customer Record With this ID!";
            upMsg = "Successfully Updated";

        }
        country.getSelectionModel().select(0);
        for (Country c : countries) {
            country.getItems().add(c.getCountryName());
        }

    }

    /**
     * This method is to add record of customer in database
     *
     * @param event event
     */
    @FXML
    private void addCustomer(ActionEvent event) {
        //method invokes if user clicks on add record button
        //condition checks if any attribute is empty
        if (division.getSelectionModel().getSelectedIndex() == -1 || country.getSelectionModel().getSelectedIndex() == -1 || id.getText().isEmpty() || name.getText().isEmpty() || postalCode.getText().isEmpty() || phoneNumber.getText().isEmpty() || address.getText().isEmpty() || division.getSelectionModel().getSelectedIndex() == 0 || country.getSelectionModel().getSelectedIndex() == 0) {
            //display error message
            new Alert(Alert.AlertType.ERROR, emptyMsg).showAndWait();
        } else {        //no field is empty

            if (modify) {
                new Alert(Alert.AlertType.ERROR, "Click modify button to save results.").showAndWait();

            } else {
                //creating customer object

                String divID = null;
                for (Division div : Database.getDivisionsRecord()) {
                    if (division.getSelectionModel().getSelectedItem().equals(div.getDivisionName())) {
                        divID = div.getDivisionID();
                    }
                }
                String createdBy = "";
                for (User user : Database.getUsersData()) {
                    if (user.getUserID().equals(userID)) {
                        createdBy = user.getUserName();
                    }
                }

                Date date = new Date();
                SimpleDateFormat ft1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:hh");
                String time = ft1.format(date);
                Customer customer = new Customer(id.getText(), name.getText(), postalCode.getText(), phoneNumber.getText(), address.getText(), country.getSelectionModel().getSelectedItem(), divID);
                //using db createCustomer method to add record in database
                Database.addCustomer(customer, time, createdBy, time, createdBy);
                //display message box
                new Alert(Alert.AlertType.INFORMATION, sMsg).showAndWait();
                //reset fields to by default values
                id.setText(new Random().nextInt(3000) + "");
                name.setText("");
                postalCode.setText("");
                phoneNumber.setText("");
                address.setText("");
                showCustomerData();
            }

        }

    }

    /**
     * This method is used to delete the customer record in database
     *
     * @param event event
     */
    @FXML
    private void deleteCustomer(ActionEvent event) {  //method invokes when user clicks on delete record button
        if (table.getSelectionModel().getSelectedIndex() == -1) {   //conditionif customer id is empty
            //display error message
            new Alert(Alert.AlertType.ERROR, delEmpMsg).showAndWait();
        } else {
            //using deletcustomer method to delete detail in database
            Customer customer = table.getSelectionModel().getSelectedItem();
            Database.deleteCustomer(customer.getCustomerID());
            //displaying message box showing record is deleted in database
            new Alert(Alert.AlertType.INFORMATION, delMsg).showAndWait();
            showCustomerData();     //update data in tableview
            id.setText(new Random().nextInt(3000) + "");

        }
    }

    /**
     * This method is used to update the customer Record in database
     *
     * @param event
     */
    @FXML
    private void updateCustomer(ActionEvent event) {      //method if user clicks on update record button
        if (check == false) {       //check condition
            if (table.getSelectionModel().getSelectedIndex() == -1) {   //id customer id is empty
                //displaying error message
                new Alert(Alert.AlertType.ERROR, delEmpMsg).showAndWait();
            } else {

                //retrieving values from database
                Customer cs = table.getSelectionModel().getSelectedItem();
                System.out.println("ok");
                if (cs != null) {
                    //setting values in fields from database so that user update
                    id.setText(cs.getCustomerID());
                    name.setText(cs.getCustomerName());
                    postalCode.setText(cs.getPostalCode());
                    phoneNumber.setText(cs.getPhoneNumber() + "");
                    address.setText(cs.getAddress());
                    country.getSelectionModel().select(cs.getCountry());
                    division.getSelectionModel().select(cs.getDivision());
                    id.setEditable(false);
                    modify = true;

                } else {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Error...");
                    alert.setHeaderText("No Record Found!");
                    alert.setContentText("");
                    alert.showAndWait();
                }
                check = true;
            }
        } else {

            if (division.getSelectionModel().getSelectedIndex() == 0 || country.getSelectionModel().getSelectedIndex() == 0 || id.getText().isEmpty() || name.getText().isEmpty() || postalCode.getText().isEmpty() || phoneNumber.getText().isEmpty() || address.getText().isEmpty()) {
                //display error message
                new Alert(Alert.AlertType.ERROR, emptyMsg).showAndWait();
            } else {

                String divID = null;
                for (Division div : Database.getDivisionsRecord()) {
                    if (division.getSelectionModel().getSelectedItem().equals(div.getDivisionName())) {
                        divID = div.getDivisionID();
                    }
                }
                Customer c = new Customer(id.getText(), name.getText(), postalCode.getText(), phoneNumber.getText(), address.getText(), country.getSelectionModel().getSelectedItem(), divID);
                String updatedBy = "";
                for (User user : Database.getUsersData()) {
                    if (user.getUserID().equals(userID)) {
                        updatedBy = user.getUserName();
                    }
                }
                Date date = new Date();
                SimpleDateFormat ft1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:hh");
                String time = ft1.format(date);
                //update customer data
                Database.editCustomer(c, time, updatedBy);
                new Alert(Alert.AlertType.INFORMATION, upMsg).showAndWait();
                check = false;
                id.setText(new Random().nextInt(3000) + "");
                name.setText("");
                postalCode.setText("");
                phoneNumber.setText("");
                address.setText("");
                country.getSelectionModel().select(0);
                division.getSelectionModel().select(0);
                modify = false;

                showCustomerData();
                id.setEditable(false);
            }

        }

    }

    /**
     * This method adds Customer details in table
     */
    public void showCustomerData() {
        //show customer details in table view
        try {
            table.setItems(populateCustmer());
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     * The method gets and store customer details in arraylist
     * Lambda expression is used here to add customers to the observable list
     *
     * @return customer details
     * @throws SQLException throws exception
     */
    public ObservableList<Customer> populateCustmer() throws SQLException {        //using observable list to add values in tableView
        ArrayList<Customer> cs = Database.getCustData();
        ObservableList<Customer> cst = FXCollections.observableArrayList();
        cs.forEach(c -> {
            cst.add(c);
        });

        return cst;
    }

    /**
     * This method add state in combo box when user selects any country
     *
     * @param event event
     */
    @FXML
    private void selectCountry(ActionEvent event) {
        division.getItems().clear();
        if (language.equals("French")) {
            division.getItems().add("sélectionner");
        } else {

            division.getItems().add("Select Division");
        }
        division.getSelectionModel().select(0);
        String cID = null;
        for (Country c : countries) {
            if (country.getSelectionModel().getSelectedItem().equals(c.getCountryName())) {
                cID = c.getCountryID();
            }
        }

        for (Division d : divisions) {
            if (d.getCountryID().equals(cID)) {
                division.getItems().add(d.getDivisionName());
            }
        }

    }

    /**
     * This method navigates user back to main menu
     *
     * @param event
     */
    @FXML
    private void gotoHomeScreen(ActionEvent event) {
        try {
            FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/view/MainMenu.fxml"));
            Parent root = fXMLLoader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Main Menu");
            Scene scene = new Scene(root);
            stage.setScene(scene);
            MainMenu controller = fXMLLoader.getController();
            controller.initiallizeData(userID, true, language);
            stage.show();
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

}
