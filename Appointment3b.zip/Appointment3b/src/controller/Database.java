package controller;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicReference;

import model.Appointment;
import model.Contact;
import model.Country;
import model.Customer;
import model.Division;
import model.User;


/**
 *
 * This Class is to establish connection with database and perform activities
 * relating to database such as adding, modifying or deleting scheduled
 * appointment or customers record
 */
public class Database {

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
    static ZoneId zone = ZoneId.systemDefault();


    /**
     * This method establish connection with database
     *
     * @return Connection to database
     */
    public static Connection createConnection() {
        Connection Con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Con = DriverManager.getConnection("jdbc:mysql://localhost:3306/client_schedule", "root", "Passw8rd!");    //Connecting to Databse
        } catch (Exception e) {
            e.printStackTrace();

        }
        return Con;         //returning Connection

    }

    /**
     * The method add Customer detail in database
     *
     * @param customer customer details
     * @param date date
     * @param createdBy created by
     * @param lastUpdate - last updated date
     * @param lastUpdatedBy - user who last updated this
     */
    public static void addCustomer(Customer customer, String date, String createdBy, String lastUpdate, String lastUpdatedBy) {
        try {
            Connection con = createConnection();           //establish Connection with database
            //query for customer data insertion
            String query = "insert INTO customer values(?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement PR = con.prepareStatement(query);
            //inserting values using prepared statement
            PR.setInt(1, Integer.valueOf(customer.getCustomerID()));
            PR.setString(2, customer.getCustomerName());
            PR.setString(3, customer.getAddress());
            PR.setString(4, customer.getPostalCode());
            PR.setString(5, String.valueOf(customer.getPhoneNumber()));
            PR.setString(6, date);
            PR.setString(7, createdBy);
            PR.setString(8, lastUpdate);
            PR.setString(9, lastUpdatedBy);
            PR.setInt(10, Integer.valueOf(customer.getDivision()));
            PR.execute();    //executing statement to add data
            con.close();        //closing connection after done inserting data in database
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     * The method delete the customer Detail in database
     *
     * @param ID - customer id to delete
     */
    public static void deleteCustomer(String ID) {
        try {

            String query = "DELETE from customer WHERE customer_id=?";   //query for deletion data from database
            Connection Con = createConnection();           //establish connection with database
            PreparedStatement pst = Con.prepareStatement(query);        //using prepared statment to execute query
            pst.setString(1, ID);       //matching condition
            pst.executeUpdate();            //execute statment
            Con.close();        //close connection
        } catch (Exception e) {
            System.out.println(e);
        }
        //delete that customer data in appointment table too
        try {
            String query = "DELETE FROM appointment WHERE customer_ID=?";
            Connection Con = createConnection();
            PreparedStatement pst = Con.prepareStatement(query);
            pst.setString(1, ID);
            pst.executeUpdate();
            Con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     * This method updated Customer detail in database
     *
     * @param customer customer details
     * @param lastUpdate last updated date
     * @param lastUpdatedBy last updated by user
     */
    public static void editCustomer(Customer customer, String lastUpdate, String lastUpdatedBy) {
        try {
            Connection con = createConnection();                //establish connection with database
            //query for update data in database
            String query = "Update customer SET customer_Name=?,postal_Code=?,phone=?,address=?,division_ID=?,Last_Update=?,Last_Updated_By=? where customer_id='" + customer.getCustomerID() + "'";
            //using prepared statment to execute query
            PreparedStatement ps = con.prepareStatement(query); //using prepared statment to execute query
            //inserting updated customer attributes
            ps.setString(1, customer.getCustomerName());
            ps.setString(2, customer.getPostalCode());
            ps.setString(3, customer.getPhoneNumber() + "");
            ps.setString(4, customer.getAddress());
            ps.setInt(5, Integer.valueOf(customer.getDivision()));
            ps.setString(6, lastUpdate);

            ps.setString(7, lastUpdatedBy);
            ps.executeUpdate(); //executing query
            con.close();            //connection clsoing
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     * The method delete appointment detail in database
     *
     * @param ID Appointment Id
     */
    public static void deleteAppointment(String ID) {
        try {

            String query = "DELETE FROM Appointment WHERE Appointment_ID=?";  //query for deletion data from database
            Connection Con = createConnection();            //establish connection with database
            PreparedStatement pst = Con.prepareStatement(query);     //using prepared statment to execute query
            pst.setString(1, ID);           //matching condition
            pst.executeUpdate();              //execute statment
            Con.close();                         //close connection
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     * The method add appointment details in Database
     *
     * @param appointment - Appointment details
     * @param date - Appointment date
     * @param createdBy - User who created this appointment
     * @param lastUpdate - Last updated date
     * @param lastUpdatedBy Last updated by which user
     */
    public static void addAppointment(Appointment appointment, String date, String createdBy, String lastUpdate, String lastUpdatedBy) {
        System.out.println(appointment.toString());
        try {
            Connection con = createConnection();       //establish Connection with database
            //query for appointment data insertion
            String query = "insert INTO appointment values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement PR = con.prepareStatement(query);
            //inserting values using prepared statement
            PR.setInt(1, Integer.valueOf(appointment.getAppointmentID()));
            PR.setString(2, appointment.getTitle());
            PR.setString(3, appointment.getDescription());
            PR.setString(4, appointment.getLocation());
            PR.setString(5, appointment.getType());
            PR.setTimestamp(6, Timestamp.valueOf(appointment.getStartDate()));
            PR.setTimestamp(7, Timestamp.valueOf(appointment.getEndDate()));
            PR.setString(8, date);
            PR.setString(9, createdBy);
            PR.setString(10, lastUpdate);
            PR.setString(11, lastUpdatedBy);
            PR.setInt(12, Integer.valueOf(appointment.getCustomerID()));
            PR.setInt(13, Integer.valueOf(appointment.getUserID()));
            PR.setInt(14, Integer.valueOf(appointment.getContactID()));

            PR.execute();       //executing statement to add data
            con.close();        //closing connection after done inserting data in database
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     * This method updated appointment detail in database
     *
     * @param appointment Appointment details
     * @param lastUpdate Last updated date
     * @param lastUpdateBy Last updated by which user
     */
    public static void editAppointment(Appointment appointment, String lastUpdate, String lastUpdateBy) {
        System.out.println("Fine");
        try {
            Connection con = createConnection();       //establish database connection
            //query to update appointment details
            String query = "Update appointment SET Title=?,Description=?,Location=?,Type=?,Start=?,End=?,Last_Update=?,Last_Updated_By=?,Customer_ID=?,User_ID=? where Appointment_ID='" + appointment.getAppointmentID() + "'";
            //using prepared Statement to execute query
            PreparedStatement ps = con.prepareStatement(query);
            //inserting updated values
            ps.setString(1, appointment.getTitle());
            ps.setString(2, appointment.getDescription());
            ps.setString(3, appointment.getLocation());
            ps.setString(4, appointment.getType());
            ps.setTimestamp(5, Timestamp.valueOf(appointment.getStartDate()));
            ps.setTimestamp(6, Timestamp.valueOf(appointment.getEndDate()));
            ps.setString(7, lastUpdate);
            ps.setString(8, lastUpdateBy);
            ps.setString(9, appointment.getCustomerID());
            ps.setString(10, appointment.getUserID());
            //   ps.setString(8, appointment.get());

            ps.executeUpdate();     //executing update
            con.close();        //closing connection to database
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     * This method gets Customer Data from the database
     *
     * @return available customers from database
     */
    public static ArrayList<Customer> getCustData() {
        ArrayList<Customer> customers = new ArrayList<>();  //arraylist to store all customers
        Customer customer = null;
        try {

            Connection Con = createConnection();       //establish connection to database
            Statement St = Con.createStatement();
            String Query = "Select * from customer";       //create query to get all customers from database
            ResultSet RS = St.executeQuery(Query);
            while (RS.next()) {     //using while loop to get all customers
                //store customer detail in customer object

                //    public Customer(String customerID, String customerName, String postalCode, int phoneNumber, String address, String country, String division) {
                String countryName = "";
                String divisionName = "";
                String countryID = "";
                for (Division division : getDivisionsRecord()) {
                    if (division.getDivisionID().equals(String.valueOf(RS.getInt(10)))) {
                        divisionName = division.getDivisionName();
                        countryID = division.getCountryID();
                    }
                }
                for (Country country : getCountriesRecord()) {
                    if (country.getCountryID().equals(countryID)) {
                        countryName = country.getCountryName();
                    }
                }
                customer = new Customer(RS.getString(1), RS.getString(2), RS.getString(4), RS.getString(5), RS.getString(3), countryName, divisionName);
                //add customer in arraylist
                customers.add(customer);
            }
            Con.close();        //close connection
        } catch (Exception e) {
            System.out.println(e);
        }

        customers.forEach((n) -> {      //print all the available customers
            System.out.println(n.toString());
        });
        return customers;

    }

    /**
     * This method gets Customer Report from the database
     *
     * @return data for customers report
     */
    public static ArrayList<String> getCustomerReport() {
        ArrayList<String> data = new ArrayList<>();  //arraylist to store all customers

        try {

            Connection Con = createConnection();       //establish connection to database
            Statement St = Con.createStatement();
            String Query = "Select * from customer";       //create query to get all customers from database
            ResultSet RS = St.executeQuery(Query);
            while (RS.next()) {     //using while loop to get all customers
                //store customer detail in customer object
                //add customer in arraylist
                data.add(RS.getString(8));
            }
            Con.close();        //close connection
        } catch (Exception e) {
            System.out.println(e);
        }

        return data;

    }

    /**
     * This method gets all the users from the database
     *
     * @return available users from database
     */
    public static ArrayList<User> getUsersData() {
        ArrayList<User> users = new ArrayList<>();  //arraylist to store all users
        User user = null;
        try {

            Connection Con = createConnection();       //establish connection to database
            Statement St = Con.createStatement();
            String Query = "Select * from  Users";       //create query to get all customers from database
            ResultSet RS = St.executeQuery(Query);
            while (RS.next()) {     //using while loop to get all users
                //store customer detail in customer object
                user = new User(RS.getString(1), RS.getString(2), RS.getString(3));
                //add user in arraylist
                users.add(user);
            }
            Con.close();        //close connection
        } catch (Exception e) {
            System.out.println(e);
        }

        return users;

    }

    /**
     * THis method gets all the contact information from the database
     *
     * @return available contacts from database
     */
    public static ArrayList<Contact> getContactsDetails() {
        ArrayList<Contact> contacts = new ArrayList<>();  //arraylist to store all contacts
        Contact contact = null;
        try {

            Connection Con = createConnection();       //establish connection to database
            Statement St = Con.createStatement();
            String Query = "Select * from  contacts";       //create query to get all contacts from database
            ResultSet RS = St.executeQuery(Query);
            while (RS.next()) {     //using while loop to get all contacts
                //store contact detail in customer object
                contact = new Contact(RS.getString(1), RS.getString(2), RS.getString(3));
                //add contact in arraylist
                contacts.add(contact);
            }
            Con.close();        //close connection
        } catch (Exception e) {
            System.out.println(e);
        }

        return contacts;

    }

    /**
     * Make log of user login activity
     *
     * @param userID User Id
     * @param attemptNo Number of attempt to login
     * @param DateTime date and time of login
     * @param Status Status/Result of login attempt
     */
    public static void userLogin(String userID, int attemptNo, String DateTime, String Status) {
        try {
            //writing data in file using fileWriter and buffered
            FileWriter fw = new FileWriter("login_activity.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write("Attempt No" + attemptNo);
            bw.write(",");
            bw.write("UserID#" + userID);
            bw.write(",");
            bw.write(DateTime);
            bw.write(",");
            bw.write(Status);
            bw.newLine();
            //closing files
            bw.close();
            fw.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    /**
     *This method gets the records for an Appointment whose Id is passed as the parameter
     *
     * @param ID Appointment Id
     * @return specific appointment detail
     */
    public static Appointment getAppointmentRecord(String ID) {
        Appointment appointment = null;
        try {

            Connection Con = createConnection();       //establish database connection
            Statement St = Con.createStatement();
            String Query = "Select * from  appointment where appointmentID='" + ID + "'";   //create query
            ResultSet RS = St.executeQuery(Query);
            if (RS.next()) {        //if appointment with provided appointment id exists
                //store detail in appointment object
                appointment = new Appointment(RS.getString(14), RS.getString(1), RS.getString(2), RS.getString(3), RS.getString(4), RS.getString(5),
                        RS.getTimestamp(6).toInstant().atZone(zone).toLocalDateTime(), RS.getTimestamp(7).toInstant().atZone(zone).toLocalDateTime(), RS.getString(12), RS.getString(13));
            }
            Con.close();        //close connecrion
        } catch (Exception e) {
            System.out.println(e);
        }
        return appointment;     //return appointment object with details
    }

    /**
     *This method gets all the Appointment details from the database
     *
     * @return all available details from database
     */
    public static ArrayList<Appointment> getappointmentDetails() {
        ArrayList<Appointment> appointments = new ArrayList<>();
        try {

            Connection Con = createConnection();       //establish connection
            Statement St = Con.createStatement();
            String Query = "Select * from appointment";        //create query to get details
            ResultSet RS = St.executeQuery(Query);
            while (RS.next()) {     //using while loop to get all details present in database
                //adding each appointment detail in arraylist


                Timestamp startDate = RS.getTimestamp(6);
                Timestamp endDate = RS.getTimestamp(7);

                //zone = ZoneId.of("America/New_York");

                ZonedDateTime zTime = startDate.toInstant().atZone(zone);
                LocalDateTime startd = zTime.toLocalDateTime();

                zTime = endDate.toInstant().atZone(zone);
                LocalDateTime endd = zTime.toLocalDateTime();

                appointments.add(new Appointment(RS.getString(14), RS.getString(1), RS.getString(2), RS.getString(3), RS.getString(4), RS.getString(5), startd, endd, RS.getString(12), RS.getString(13)));


            }
            Con.close();        //close connection
        } catch (Exception e) {
            System.out.println(e);
        }

        return appointments;        //return arraylist
    }

    /**
     * This method gets all the country data from the database
     *
     * @return all the available countries from database
     */
    public static ArrayList<Country> getCountriesRecord() {
        ArrayList<Country> countries = new ArrayList<>();
        try {

            Connection Con = createConnection();       //establish connection
            Statement St = Con.createStatement();
            String Query = "Select * from  countries";        //create query to get details
            ResultSet RS = St.executeQuery(Query);
            while (RS.next()) {     //using while loop to get all details present in database
                //adding each country detail in arraylist
                countries.add(new Country(RS.getString(1), RS.getString(2)));
            }
            Con.close();        //close connection
        } catch (Exception e) {
            System.out.println(e);
        }

        return countries;        //return arraylist
    }

    /**
     * This method gets all the division data from the database
     *
     * @return all divisions from database
     */
    public static ArrayList<Division> getDivisionsRecord() {
        ArrayList<Division> divisions = new ArrayList<>();
        try {

            Connection Con = createConnection();       //establish connection
            Statement St = Con.createStatement();
            String Query = "Select * from  first_level_division";        //create query to get details
            ResultSet RS = St.executeQuery(Query);
            while (RS.next()) {     //using while loop to get all details present in database
                //adding each country detail in arraylist
                ////System.out.println(RS.getString(1)+",,"+ RS.getString(2)+",,"+ RS.getString(7));
                divisions.add(new Division(RS.getString(1), RS.getString(2), RS.getString(7)));
            }
            Con.close();        //close connection
        } catch (Exception e) {
            System.out.println(e);
        }

        return divisions;        //return arraylist
    }

    /**
     * This method gets customer data for a specific customer
     *
     * @param ID id of customer to get the data for
     * @return specific customer from database
     */
    public static Customer getCustomerData(String ID) {
        Customer customer = null;
        try {

            Connection Con = createConnection();       //establish database connection
            Statement St = Con.createStatement();
            String Query = "Select * from customer where Customer_Id='" + ID + "'"; //create query to get detail
            ResultSet RS = St.executeQuery(Query);
            if (RS.next()) {        //if customer detail exist with provided id
                customer = new Customer(RS.getString(1), RS.getString(2), RS.getString(3), RS.getString(4), RS.getString(5), RS.getString(6), RS.getString(7));
            }
            Con.close();        //closing connection
        } catch (Exception e) {
            System.out.println(e);
        }
        return customer;
    }

    /**
     * Method to check if an appointment existed in next 15 min
     *
     * Lambda expression here is used for iterating through appointments list and  getting the appointment
     * that is to start in next 15 min from the time specified
     *
     * @param date date to get appointment for
     * @return gets the first appointment which is in the next 15 min of logging in
     */
    public static Appointment getIncomingAppointment(LocalDateTime date) {
        ArrayList<Appointment> listApp = getappointmentDetails();
        AtomicReference<Appointment> appointment = new AtomicReference<>();

        listApp.forEach(app -> {
            long minutes = ChronoUnit.MINUTES.between(date, app.getStartDate());
            if (minutes >= 0 && minutes <= 15 && appointment.get() == null) {
                appointment.set(app);
            }
        });


        return appointment.get();
    }

}
