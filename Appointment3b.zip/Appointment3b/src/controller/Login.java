package controller;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Appointment;
import model.User;

/**
 *
 * This class controls the functionality of Login View
 */
public class Login implements Initializable {


    @FXML
    private Button btnLbl;
    @FXML
    private TextField id ,password;
    @FXML
    private RadioButton eRadio, fRadio;
    @FXML
    private Label location, idLbl, pswdLbl, lcLbl, h1;

    private String successMessage, errorMessage, msg;

    int attempt;
    Date date;

    String lngl = "";


    /**
     * Initialize all variables
     *
     * @param url url
     * @param rb ResourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        attempt = 1;
        date = new Date();
        successMessage = "Successfully Login";
        msg = "No Field can be empty";
        errorMessage = "Invalid Credentials.Try Again";

        ZoneId zone = ZoneId.systemDefault();

        String local_language = System.getProperty("user.language");

        location.setText(zone + "");
        if(local_language.equals("fr")) {

            // username1
            // password1
            // for test
            id.setText("username1");
            password.setText("password1");

            fRadio.setSelected(true);
            eRadio.setSelected(false);
        } else {

            eRadio.setSelected(true);
            fRadio.setSelected(false);
        }


        if (eRadio.isSelected()) {
            lngl = "English";
            selectEnglish();
        } else {
            lngl = "French";
            selectFrench();
        }
    }

    /**
     * This method is used to Login a User
     *
     * @param event event
     */
    @FXML
    private void login(ActionEvent event) {

        if (id.getText().isEmpty() || password.getText().isEmpty()) {   //check if id & password field is populated or not
            //display error message
            new Alert(Alert.AlertType.INFORMATION, msg).showAndWait();
            SimpleDateFormat ft1 = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a zzz");
            String time = ft1.format(date);
            //use userLog method to add login detail in textfile
            Database.userLogin(null, attempt, time, "Login Fail");
            attempt++;

        } else {
            String ID = null;
            ArrayList<User> users = Database.getUsersData();
            boolean flag = false;
            for (User user : users) {

                if (id.getText().equals(user.getUserName()) && password.getText().equals(user.getUserPassword())) {
                    flag = true;
                    ID = user.getUserID();
                }
            }
            if (flag) { //if id and password matches
                SimpleDateFormat ft1 = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a zzz");
                String time = ft1.format(date);
                Database.userLogin(ID, attempt, time, "Login Successful");
                //navigate to customer Record screen

                new Alert(Alert.AlertType.INFORMATION, successMessage).showAndWait();

                try {
                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/MainMenu.fxml"));
                    Parent root = fxmlLoader.load();
                    Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                    stage.setTitle("Customer Record");
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    MainMenu controller = fxmlLoader.getController();
                    controller.initiallizeData(ID, lngl);
                    stage.show();
                } catch (IOException ex) {
                    System.out.println(ex);
                }

            } else {
                //display error message
                new Alert(Alert.AlertType.INFORMATION, errorMessage).showAndWait();
                SimpleDateFormat ft1 = new SimpleDateFormat("yyyy:MM:dd hh:mm:ss a zzz");
                String time = ft1.format(date);
                Database.userLogin(null, attempt, time, "Login Fail");
                attempt++;
            }
        }
    }

    /**
     * This method is used to change the selected language to English
     */
    @FXML
    private void selectEnglish() {
        idLbl.setText("Username");
        h1.setText("Login User");
        pswdLbl.setText("Password");
        lcLbl.setText("Location");
        btnLbl.setText("Login");
        successMessage = "Successfully Login";
        msg = "No Field can be empty";
        errorMessage = "Invalid Credentials.Try Again";

    }

    /**
     * This method is used to change the selected language to French
     */
    @FXML
    private void selectFrench() {
        idLbl.setLayoutX(10);
        idLbl.setText("Identifiant d'utilisateur");
        h1.setText("Connexion");
        pswdLbl.setText("Mot de passe");
        lcLbl.setText("Emplacement");
        btnLbl.setText("Connexion");
        successMessage = "Connexion réussie";
        msg = "Aucun champ ne peut être vide";
        errorMessage = "Les informations d'identification invalides. Réessayer";

    }

}
