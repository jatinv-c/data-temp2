package controller;

import java.io.IOException;
import java.net.URL;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import model.Appointment;

/**
 *
 * This Class holds functionality that controls user navigation choice (Perform
 * which functionality) functionality
 */
public class MainMenu implements Initializable {


    String id, language, logMsg = "";
    ArrayList<Appointment> appointments;

    @FXML
    private Label h1;
    @FXML
    private Button btn1, btn2, btn3, btn4;

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

    /**
     * This method initialize all attributes
     *
     * @param url url
     * @param rb Resource Bundle
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        appointments = Database.getappointmentDetails();
    }

    /**
     * This method is used to set the data to the UI elements
     *
     * @param id user id
     * @param value value
     * @param language selected language
     */ 
    public void initiallizeData(String id, boolean value, String language) {

        this.id = id;
        this.language = language;
        String msg = "You have";
        String msg1 = "Upcomming Meetings";
        String msg2 = "You have no upcomming meeting in 15 minutes";
        logMsg = "Successfully Logout";
        if (language.equals("French")) {
            h1.setText("Système de prise de rendez-vous");
            btn1.setText("ajouter fiche client       ");
            btn2.setText("Rendez-vous                ");
            btn3.setText("afficher les rapports");
            btn4.setText("Se déconnecter           ");
            msg = "vous avez";
            msg1 = "réunion à venir";
            msg2 = "Vous n'avez pas de rendez-vous à venir dans 15 minutes";
            logMsg = "Déconnexion réussie";
        }

    }

    /**
     * Initialize values
     *
     * @param id user id
     * @param language selected language
     */
    public void initiallizeData(String id, String language) {
        this.id = id;
        this.language = language;
        String msg = "You have";
        String msg1 = " an upcoming Meetings";
        String msg2 = "You have no upcomming neeting in 15 minutes";
        if (language.equals("French")) {
            h1.setText("Système de prise de rendez-vous");
            btn1.setText("ajouter fiche client       ");
            btn2.setText("Rendez-vous                ");
            btn3.setText("afficher les rapports");
            btn4.setText("Se déconnecter           ");
            msg = "vous avez";
            msg1 = " un réunion à venir";
            msg2 = "Vous n'avez pas de rendez-vous à venir dans 15 minutes";
        }

        Appointment comingAppointment = Database.getIncomingAppointment(LocalDateTime.now());
        if(comingAppointment != null) {
            String detail = "\n" + comingAppointment.getAppointmentID() + "\t\t\t" + comingAppointment.getStartDate() + "";
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Message...");
            alert.setHeaderText(msg + msg1);
            alert.setContentText("Appointment ID\t\t\tDate&Time\n" + detail);
            alert.showAndWait();
        }

    }

    /**
     * Navigates user to customer Record Screen
     *
     * @param event event
     */
    @FXML
    private void addCustRecord(ActionEvent event) {
        try {
            FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/view/CustomerManage.fxml"));
            Parent root = fXMLLoader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Customer Record");
            Scene scene = new Scene(root);
            CustomerManager controller = fXMLLoader.getController();
            controller.setUserValues(id, language);
            stage.setScene(scene);
            stage.show();
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    /**
     * Navigates User to Appointment Schedule Screen
     *
     * @param event
     */
    @FXML
    private void scheduleAppointment(ActionEvent event) {
        try {
            FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/view/AppointmentManage.fxml"));
            Parent root = fXMLLoader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Customer Record");
            Scene scene = new Scene(root);
            stage.setScene(scene);
            AppointmentManager controller = fXMLLoader.getController();
            controller.setUserData(language);
            stage.show();
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    /**
     * This method is use to logout user and navigates back to login screen
     *
     * @param event
     */
    @FXML
    private void logoutUser(ActionEvent event) {
        new Alert(Alert.AlertType.INFORMATION, logMsg).showAndWait();
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/view/Login.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Customer Record");
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    /**
     * This method navigates user to reports Screen
     *
     * @param event
     */
    @FXML
    private void showReports(ActionEvent event) {
        try {
            FXMLLoader fXMLLoader = new FXMLLoader(getClass().getResource("/view/Reports.fxml"));
            Parent root = fXMLLoader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setTitle("Appointment ReportsCon");
            Scene scene = new Scene(root);
            stage.setScene(scene);
            ReportsCon controller = fXMLLoader.getController();
            controller.initializeData(id, language);
            stage.show();
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

}
