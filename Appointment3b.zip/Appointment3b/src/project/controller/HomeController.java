package project.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import project.App;
import project.model.Appointment;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Controller for Home Screen
 */
public class HomeController implements Initializable {

    /**
     * Initializes the fxml screen
     * @param url url
     * @param resourceBundle resource bundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    /**
     * Method to navigate to Customer Management Screen
     * @param event - event
     */
    @FXML
    void onCustomerButtonClicked(ActionEvent event) {
        try {
            App.setRoot("Customer");
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    /**
     * Method to navigate to Appointment Management Screen
     * @param event - event
     */
    @FXML
    void onAppointmentButtonClicked(ActionEvent event) {
        try {
            App.setRoot("Appointments");
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    /**
     * Method to navigate to Report Screen
     * @param event - event
     */
    @FXML
    void onReportButtonClicked(ActionEvent event) {
        try {
            App.setRoot("Reports");
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    /**
     * Method to log out of the application
     * @param event - event
     */
    @FXML
    void onLogoutButtonClicked(ActionEvent event) {
        App.currentUser = null;

        Alert alert = new Alert(Alert.AlertType.INFORMATION, "Successfully Logged Out!!");
        alert.setHeaderText(null);
        alert.setTitle("Logged Out");
        alert.showAndWait();
        try {
            App.setRoot("Login");
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    /**
     * Method to check If there is an appointment in the next 15 minutes
     */
    public static void checkUpcomingAppointment(){
        //check if there is any appointment in next 15 mins
        ObservableList<Appointment> appointmentList = FXCollections.observableArrayList(DbController.getInstance().getAppointmentList());
        Optional<Appointment> app = appointmentList.stream().filter(e -> e.getStart().atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime().isAfter(LocalDateTime.now()) && e.getStart().atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime().isBefore(LocalDateTime.now().plusMinutes(15))).findFirst();
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Message...");
        if (app.isPresent()) {
            alert.setHeaderText("Appointment Alert!!!");
            alert.setContentText("You have the following appointment in the next 15 minutes:-\n"
                    + "Appointment Id: " + app.get().getId() + "\n"
                    + "Date: " + app.get().getStart().atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime().toLocalDate() + "\n"
                    + "Time: " + app.get().getStart().atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime().toLocalTime() + "\n");
        } else {
            alert.setHeaderText(null);
            alert.setContentText("You have no upcoming appointments.");
        }
        alert.showAndWait();
    }

}
