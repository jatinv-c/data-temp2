package project.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.Callback;
import project.model.Country;
import project.model.Customer;
import project.model.Division;

import java.net.URL;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

/**
 * Controller for Customer Information screen
 */
public class CustomerInformationController implements Initializable {
    @FXML
    private TextField nameTF;

    @FXML
    private TextField phoneNoTF;

    @FXML
    private TextField addressTF;

    @FXML
    private Label h1;

    @FXML
    private ComboBox<Country> countryCB;

    @FXML
    private Button addButton;

    @FXML
    private Label addressLabel;

    @FXML
    private TextField customerIdTF;

    @FXML
    private Label phoneLabel;

    @FXML
    private Label divisionLabel;

    @FXML
    private Label customerIdLabel;

    @FXML
    private Label coutryLabel;

    @FXML
    private Button backButton;

    @FXML
    private Label postalLabel;

    @FXML
    private TextField postalCodeTF;

    @FXML
    private Label nameLabel;

    @FXML
    private ComboBox<Division> divisionCB;

    ObservableList<Country> countryList;
    ObservableList<Division> divisionList;

    static Customer customer;

    static boolean editMode;

    static int newCustomerId;

    /**
     * Initializes the fxml screen
     * @param url url
     * @param resourceBundle resource bundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //Get countries list
        countryList = FXCollections.observableArrayList(DbController.getInstance().getCountryList());
        //Combo Box has countries object. To show only the country name
        //create a custom factory
        Callback<ListView<Country>, ListCell<Country>> factory_country = lv -> new ListCell<Country>() {
            @Override
            protected void updateItem(Country item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty ? "" : item.getCountry());
            }
        };
        //set custom factory to combo box cell factory
        countryCB.setCellFactory(factory_country);
        //set the item of combo box to country list
        countryCB.setItems(countryList);
        countryCB.setButtonCell(factory_country.call(null));

        //Get divisions list
        divisionList = FXCollections.observableArrayList(DbController.getInstance().getDivisionList());
        //create a custom factory
        Callback<ListView<Division>, ListCell<Division>> factory_division = lv -> new ListCell<Division>() {
            @Override
            protected void updateItem(Division item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty ? "" : item.getDivision());
            }
        };
        //set custom factory to combo box cell factory
        divisionCB.setCellFactory(factory_division);
        //set the item of combo box to country list
        divisionCB.setItems(divisionList);
        divisionCB.setButtonCell(factory_division.call(null));

        if (editMode) {
            setCustomerDataToForm(customer);
            addButton.setText("Update");
        } else {
            customerIdTF.setText(newCustomerId + "");
        }

        customerIdTF.setEditable(false);
    }

    /**
     * Method which is called when a country is selected in the combo box.
     * On selection of country the divisions of that country should only show up
     * in the division box.
     * <p>
     * Stream API - to filter the divisions based on country id
     *
     * @param event
     */
    @FXML
    void selectCountry(ActionEvent event) {
        int selectedCountryId = countryCB.getSelectionModel().getSelectedItem().getCountryId();
        List<Division> filteredDivisionList = divisionList.stream()
                .filter(e -> e.getCountryId() == selectedCountryId)
                .collect(Collectors.toList());
        divisionCB.setItems(FXCollections.observableArrayList(filteredDivisionList));
    }

    /**
     * Method that is called when user clicks on Add button
     * @param event event
     */
    @FXML
    void onAddButonClicked(ActionEvent event) {

        if (!validateForm()){
            return;
        }

        Customer cust = new Customer(
                Integer.parseInt(customerIdTF.getText()),
                nameTF.getText(),
                addressTF.getText(),
                postalCodeTF.getText(),
                phoneNoTF.getText(),
                divisionCB.getValue().getDivisionId()
        );
        if (editMode) {
            DbController.getInstance().updateCustomer(cust);
            showInfoAlert("Appointment data successfully updated!!");
        } else {
            DbController.getInstance().addCustomer(cust);
            showInfoAlert("Appointment data successfully updated!!");
        }

        //close the add window
        ((Stage) addButton.getScene().getWindow()).close();
    }

    /**
     * Method that is called when user clicks on Back button
     * @param event event
     */
    @FXML
    void onBackButtonClicked(ActionEvent event) {
        ((Stage) addButton.getScene().getWindow()).close();
    }

    /**
     * Sets the customer data in the form.
     * Used lambda expression to get selected division and country in the contact
     * from the contact list
     *
     * @param cust customer object data to set to form
     */
    public void setCustomerDataToForm(Customer cust) {
        customerIdTF.setText(cust.getCustomerId() + "");
        nameTF.setText(cust.getCustomerName());
        phoneNoTF.setText(cust.getPhone());
        postalCodeTF.setText(cust.getPostalCode());
        addressTF.setText(cust.getAddress());

        //set division
        Optional<Division> d = divisionList.stream().filter(e -> e.getDivisionId() == cust.getDivisionId()).findFirst();
        if (d.isPresent()) {
            divisionCB.setValue(d.get());

            //set country
            Optional<Country> c = countryList.stream().filter(e -> e.getCountryId() == d.get().getCountryId()).findFirst();
            if (c != null) {
                countryCB.setValue(c.get());
            }
        }
    }

    /**
     * Method to perform form input validations
     *
     * @return true if all validations are passed, false otherwise
     */
    public boolean validateForm() {
        if (nameTF.getText().isEmpty()
                || addressTF.getText().isEmpty()
                || postalCodeTF.getText().isEmpty()
                || phoneNoTF.getText().isEmpty()
                || countryCB.getValue() == null
                || divisionCB.getValue() == null) {

            ResourceBundle bundle = ResourceBundle.getBundle("project/localization/localization", new Locale("en"));

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Validation Error");
            alert.setContentText(bundle.getString("validationMsg"));
            alert.showAndWait();
            return false;
        }
        return true;
    }

    /**
     * Method to show a message dialog box
     * @param msg Message to display in the dialog
     */
    public void showInfoAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setTitle("Success!!");
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
