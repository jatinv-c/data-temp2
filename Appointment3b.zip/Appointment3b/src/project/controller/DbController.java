package project.controller;

import project.App;
import project.model.*;

import java.io.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

/**
 * Singleton DbController Class. Can be used anywhere in the project
 * using the getInstance() method
 */
public class DbController {

    private static DbController dbController = null;

    private final String HOST_PORT = "localhost:3306";
    private final String USERNAME = "root";
    private final String PASSWORD = "root";
    private final String DB_NAME = "temp";
    private final String URL = "jdbc:mysql://" + HOST_PORT + "/" + DB_NAME;

    private Connection connection;


    /**
     * Private constructor called only once so this class is not initialized more than once.
     * Create the db connection first time the class is initialized in the private constructor.
     */
    private DbController() {
        System.out.println("Prvate const called");
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Used to get an instance of DbController class. If the instance is null than creates a new instance
     *
     * @return an instance of DbController class
     */
    public static DbController getInstance() {
        if (dbController == null) {
            dbController = new DbController();
        }
        return dbController;
    }

    /**
     * Method to close the db connection
     */
    private void closeConnection() {
        try {
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to validate the user
     * @param username  user id
     * @param password  password
     * @return true if the user exists and password is correct, false otherwise
     * @throws IOException if the login activity is not found or cannot be craeted
     */
    public boolean validateUser(String username, String password) throws IOException {

        boolean res = false;

        File file = new File("login_activity.txt");
        if (!file.exists()){
            file.createNewFile();
        }

        //Log user attempt
        String log = LocalDateTime.now(ZoneOffset.UTC) + ": User " + username;
        String query = "select * from users where username = ? and password = ?";
        try {
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                User user = new User(rs.getString("user_id"), username, password);
                System.out.println("current user - " + user);
                App.currentUser = user;
                log += " has logged in.";
                res = true;
            }else{
                log += " logon attempt failed.";
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
        PrintWriter pw = new PrintWriter(bw);
        pw.write(log + "\n");
        bw.close();
        return res;
    }

    /**
     * Method to get customer list from database
     * @return list of customer objects
     */
    public List<Customer> getCustomerList() {
        List<Customer> customerList = new ArrayList<>();

        String query = "select * from customer";

        try {
            ResultSet rs = connection.createStatement().executeQuery(query);
            while (rs.next()) {
                Customer customer = new Customer(rs.getInt("customer_id"),
                        rs.getString("customer_name"),
                        rs.getString("address"),
                        rs.getString("postal_code"),
                        rs.getString("phone"),
                        rs.getInt("division_id")
                );
                customerList.add(customer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return customerList;
    }

    /**
     * Method to get country list from database
     * @return list of country objects
     */
    public List<Country> getCountryList() {
        List<Country> countryList = new ArrayList<>();

        String query = "select * from countries";

        try {
            ResultSet rs = connection.createStatement().executeQuery(query);
            while (rs.next()) {
                Country country = new Country(rs.getInt("country_id"),
                        rs.getString("country"));
                countryList.add(country);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return countryList;
    }

    /**
     * Method to get divisions from the database
     * @return list of divisions objects
     */
    public List<Division> getDivisionList() {
        List<Division> divisionList = new ArrayList<>();

        String query = "select * from first_level_division";

        try {
            ResultSet rs = connection.createStatement().executeQuery(query);
            while (rs.next()) {
                Division division = new Division(rs.getInt("division_id"),
                        rs.getString("division"),
                        rs.getInt("country_id"));
                divisionList.add(division);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return divisionList;
    }

    /**
     * Method to add new customer to the database
     * @param customer customer to add
     * @return true if the operation is successful, false otherwise
     */
    public boolean addCustomer(Customer customer) {
        String query = "insert into customer(customer_id, customer_name, address, postal_code," +
                "phone, create_date, created_by, last_updated_by, division_id) " +
                "values(?,?,?,?,?,?,?,?,?)";

        try {
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, customer.getCustomerId());
            stmt.setString(2, customer.getCustomerName());
            stmt.setString(3, customer.getAddress());
            stmt.setString(4, customer.getPostalCode());
            stmt.setString(5, customer.getPhone());
            stmt.setDate(6, new Date(System.currentTimeMillis()));
            stmt.setString(7, App.currentUser.getName());
            stmt.setString(8, App.currentUser.getName());
            stmt.setInt(9, customer.getDivisionId());

            return stmt.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Method to update an existing customer to the database
     * @param customer customer to update
     * @return true if the operation is successful, false otherwise
     */
    public boolean updateCustomer(Customer customer) {
        String query = "update customer set customer_name = ?, address = ?, postal_code = ?," +
                "phone = ?, last_updated_by = ?, division_id = ? where customer_id = ?";

        try {
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, customer.getCustomerName());
            stmt.setString(2, customer.getAddress());
            stmt.setString(3, customer.getPostalCode());
            stmt.setString(4, customer.getPhone());
            stmt.setString(5, App.currentUser.getName());
            stmt.setInt(6, customer.getDivisionId());
            stmt.setInt(7, customer.getCustomerId());

            return stmt.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Method to delete customer data from database
     * @param customerId customer id to delete
     * @return true if the operation is success, false otherwise
     */
    public boolean deleteCustomer(int customerId) {
        String query = "delete from appointment where customer_id = ?";

        try {
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, customerId);

            stmt.execute();

            query = "delete from customer where customer_id = ?";

            stmt = connection.prepareStatement(query);
            stmt.setInt(1, customerId);

            return stmt.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Method to get all the appointments from database
     *
     * @return - a list of all available appointments
     */
    public List<Appointment> getAppointmentList() {
        List<Appointment> appointmentList = new ArrayList<>();

        String query = "select * from appointment";

        try {
            ResultSet rs = connection.createStatement().executeQuery(query);
            while (rs.next()) {
                Appointment appointment = new Appointment(rs.getInt("appointment_id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getString("location"),
                        rs.getString("type"),
                        rs.getTimestamp("start").toLocalDateTime(),
                        rs.getTimestamp("end").toLocalDateTime(),
                        rs.getInt("customer_id"),
                        rs.getInt("user_id"),
                        rs.getInt("contact_id")
                );
                appointmentList.add(appointment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return appointmentList;
    }

    /**
     * Method to get all the appointments from database for the specified customer id
     * @param customerId customer id to delete
     * @return - a list of available appointments for the given customer id
     */
    public List<Appointment> getAppointmentListByCustomerId(int customerId) {
        List<Appointment> appointmentList = new ArrayList<>();

        String query = "select * from appointment where customer_id = ?";

        try {
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, customerId);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Appointment appointment = new Appointment(rs.getInt("appointment_id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getString("location"),
                        rs.getString("type"),
                        rs.getTimestamp("start").toLocalDateTime(),
                        rs.getTimestamp("end").toLocalDateTime(),
                        rs.getInt("customer_id"),
                        rs.getInt("user_id"),
                        rs.getInt("contact_id")
                );
                appointmentList.add(appointment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return appointmentList;
    }

    /**
     * Method to get all contacts from the database
     *
     * @return - a list of all contact
     */
    public List<Contact> getContactList() {
        List<Contact> contactList = new ArrayList<>();

        String query = "select * from contacts";

        try {
            ResultSet rs = connection.createStatement().executeQuery(query);
            while (rs.next()) {
                Contact contact = new Contact(rs.getInt("contact_id"),
                        rs.getString("contact_name"),
                        rs.getString("email"));
                contactList.add(contact);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return contactList;
    }

    /**
     * Method to add an appointment
     *
     * @param appointment - appointment object to add
     * @return - true if the operation is success, false otherwise
     */
    public boolean addAppointment(Appointment appointment) {
        String query = "insert into appointment(appointment_id, title, description, location, type, " +
                "start, end, create_date, created_by, last_updated_by, customer_id, user_id," +
                "contact_id) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";

        System.out.println("value to db in utc - " + appointment.getStart().atZone(ZoneOffset.UTC));

        try {
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, appointment.getId());
            stmt.setString(2, appointment.getTitle());
            stmt.setString(3, appointment.getDescription());
            stmt.setString(4, appointment.getLocation());
            stmt.setString(5, appointment.getType());

            //convert local date time to UTC
            stmt.setObject(6, appointment.getStart().atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneOffset.UTC).toLocalDateTime());
            stmt.setObject(7, appointment.getEnd().atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneOffset.UTC).toLocalDateTime());
            stmt.setObject(8, LocalDateTime.now().atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneOffset.UTC).toLocalDateTime());

            stmt.setString(9, App.currentUser.getName());
            stmt.setString(10, App.currentUser.getName());
            stmt.setInt(11, appointment.getCustomerId());
            stmt.setInt(12, appointment.getUserId());
            stmt.setInt(13, appointment.getContactId());

            System.out.println(stmt.toString());
            return stmt.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Method to update an appointment details
     *
     * @param appointment - appointment object to update
     * @return - true if the operation is success, false otherwise
     */
    public boolean updateAppointment(Appointment appointment) {
        String query = "update appointment set title = ?, description = ?, location = ?, type = ?, " +
                "start = ?, end = ?, last_updated_by = ?, customer_id = ?, user_id = ?, " +
                "contact_id = ? where appointment_id = ?";

        try {
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, appointment.getTitle());
            stmt.setString(2, appointment.getDescription());
            stmt.setString(3, appointment.getLocation());
            stmt.setString(4, appointment.getType());

            //convert local date time to UTC
            stmt.setObject(5, appointment.getStart().atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneOffset.UTC).toLocalDateTime());
            stmt.setObject(6, appointment.getEnd().atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneOffset.UTC).toLocalDateTime());

            stmt.setString(7, App.currentUser.getName());
            stmt.setInt(8, appointment.getCustomerId());
            stmt.setInt(9, appointment.getUserId());
            stmt.setInt(10, appointment.getContactId());
            stmt.setInt(11, appointment.getId());

            return stmt.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * Method to delete an appointment from the database
     * @param appointmentId appointment id to delete
     * @return true if the operation is success, false otherwise
     */
    public boolean deleteAppointment(int appointmentId) {
        String query = "delete from appointment where appointment_id = ?";

        try {
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, appointmentId);

            return stmt.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Method to get the latest customer id from the database
     * @return latest customer id
     */
    public int getMaxCustomerId(){

        String query = "select max(customer_id) from customer";
        try{
            ResultSet rs = connection.createStatement().executeQuery(query);
            if (rs.next()) {
                return rs.getInt(1);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return 10000;
    }

    /**
     * Method to get the latest appointment id from database
     * @return latest appointment id
     */
    public int getMaxAppointmentId(){

        String query = "select max(appointment_id) from appointment";
        try{
            ResultSet rs = connection.createStatement().executeQuery(query);
            if (rs.next()) {
                return rs.getInt(1);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return 10000;
    }
}
