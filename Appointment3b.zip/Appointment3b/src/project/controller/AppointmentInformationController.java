package project.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.util.Callback;
import project.App;
import project.model.Appointment;
import project.model.Contact;
import project.model.Customer;

import java.net.URL;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

/**
 * Control for Appointment Information screen
 */
public class AppointmentInformationController implements Initializable {
    @FXML
    private Label contactNameLabel;

    @FXML
    private ComboBox<Contact> contactCB;

    @FXML
    private TextField locationTF;

    @FXML
    private TextField startDateTF;

    @FXML
    private Label titleLabel;

    @FXML
    private Label appIdLabel;

    @FXML
    private Label startDateLabel;

    @FXML
    private TextField typeTF;

    @FXML
    private Label endDateLabel;

    @FXML
    private Button backButton;

    @FXML
    private TextField endDateTF;

    @FXML
    private TextField titleTF;

    @FXML
    private Label cusIdLabel;

    @FXML
    private TextField appIdTF;

    @FXML
    private Label descLabel;

    @FXML
    private TextField descTF;

    @FXML
    private Label locationLabel;

    @FXML
    private Button addButton;

    @FXML
    private ComboBox<Customer> customerIdCB;

    @FXML
    private Label scheduleLabel;

    @FXML
    private Label typeLabel;

    ObservableList<Contact> contactList;
    ObservableList<Customer> customerList;

    static Appointment appointment;

    static boolean editMode;

    static int newAppointmentId;

    DateTimeFormatter sdf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /**
     * Initializes the fxml screen
     * @param url url
     * @param resourceBundle resource bundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //Get contacts list
        contactList = FXCollections.observableArrayList(DbController.getInstance().getContactList());
        //Combo Box has contact object. To show only the contact name
        //create a custom factory
        Callback<ListView<Contact>, ListCell<Contact>> factory_contact = lv -> new ListCell<Contact>() {
            @Override
            protected void updateItem(Contact item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty ? "" : item.getName());
            }
        };
        //set custom factory to combo box cell factory
        contactCB.setCellFactory(factory_contact);
        //set the item of combo box to contact list
        contactCB.setItems(contactList);
        contactCB.setButtonCell(factory_contact.call(null));

        //Get customers list
        customerList = FXCollections.observableArrayList(DbController.getInstance().getCustomerList());
        //Combo Box has contact object. To show only the contact name
        //create a custom factory
        Callback<ListView<Customer>, ListCell<Customer>> factory_customer = lv -> new ListCell<Customer>() {
            @Override
            protected void updateItem(Customer item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty ? "" : item.getCustomerId() + "");
            }
        };
        //set custom factory to combo box cell factory
        customerIdCB.setCellFactory(factory_customer);
        //set the item of combo box to contact list
        customerIdCB.setItems(customerList);
        customerIdCB.setButtonCell(factory_customer.call(null));

        if (editMode) {
            setAppointmentDataToForm(appointment);
            addButton.setText("Update");
        } else {
            appIdTF.setText(newAppointmentId + "");
        }

        appIdTF.setEditable(false);
    }

    /**
     * Method that is called when user clicks on Add button
     * @param event event
     */
    @FXML
    void onAddButtonClicked(ActionEvent event) {
        //perform form validation
        if (!validateForm()) {
            return;
        }

        //get the appointment values
        Appointment app = new Appointment(
                Integer.parseInt(appIdTF.getText()),
                titleTF.getText(),
                descTF.getText(),
                locationTF.getText(),
                typeTF.getText(),
                LocalDateTime.parse(startDateTF.getText(), sdf),
                LocalDateTime.parse(endDateTF.getText(), sdf),
                customerIdCB.getValue().getCustomerId(),
                Integer.parseInt(App.currentUser.getUserId()),
                contactCB.getValue().getContactId());

        //check if this appointment conflicts with any other in the database
        boolean conflict = checkAppointmentConflicts(app);
        if (conflict) {
            return;
        }

        //perform edit or add based on user action
        if (editMode) {
            DbController.getInstance().updateAppointment(app);
            showInfoAlert("Appointment data successfully updated!!");
        } else {
            DbController.getInstance().addAppointment(app);
            showInfoAlert("Appointment data successfully added!!");
        }

        //close the add window
        ((Stage) addButton.getScene().getWindow()).close();
    }

    /**
     * Method that is called when user clicks on Back button
     * @param event event
     */
    @FXML
    void onBackButtonClicked(ActionEvent event) {
        ((Stage) addButton.getScene().getWindow()).close();
    }

    /**
     * Sets the appointment data in the form.
     * Used lambda expression to get selected contact in the appointment from the contact list
     *
     * @param app appointment object data to set to form
     */
    public void setAppointmentDataToForm(Appointment app) {
        appIdTF.setText(app.getId() + "");
        titleTF.setText(app.getTitle());
        descTF.setText(app.getDescription());
        locationTF.setText(app.getLocation());
        typeTF.setText(app.getType());

        //convert UTC date time to local zone date time
        startDateTF.setText(app.getStart().atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime().format(sdf));
        endDateTF.setText(app.getEnd().atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime().format(sdf));


        Optional<Contact> contactOp = contactList.stream().filter(e -> e.getContactId() == app.getContactId()).findFirst();
        if (contactOp.isPresent()) {
            contactCB.setValue(contactOp.get());
        }

        Optional<Customer> customerOp = customerList.stream().filter(e -> e.getCustomerId() == app.getCustomerId()).findFirst();
        if (customerOp.isPresent()) {
            customerIdCB.setValue(customerOp.get());
        }

    }

    /**
     * Method to show a message dialog box
     * @param msg Message to display in the dialog
     */
    public void showInfoAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setTitle("Success!!");
        alert.setContentText(msg);
        alert.showAndWait();
    }

    /**
     * Method to perform following validations:
     * -   form inputs(including date)
     * -   verify that start date falls before end date
     * -   check if appointment is outside business hours
     *
     * @return true if all validations are passed, false otherwise
     */
    public boolean validateForm() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(null);
        alert.setTitle("Validation Error");

        //form validations
        if (titleTF.getText().isEmpty()
                || descTF.getText().isEmpty()
                || titleTF.getText().isEmpty()
                || locationTF.getText().isEmpty()
                || startDateTF.getText().isEmpty()
                || endDateTF.getText().isEmpty()
                || contactCB.getValue() == null
                || typeTF.getText().isEmpty()
                || customerIdCB.getValue() == null) {

            ResourceBundle bundle = ResourceBundle.getBundle("project/localization/localization", new Locale("en"));
            alert.setContentText(bundle.getString("validationMsg"));
            alert.showAndWait();
            return false;
        }

        //to validate date format
        String format = "[0-9]{4}[-]{1}[0-9]{2}[-]{1}[0-9]{2}[ ]{1}[0-9]{2}[:]{1}[0-9]{2}[:]{1}[0-9]{2}";
        if (!Pattern.matches(format, startDateTF.getText()) || !Pattern.matches(format, endDateTF.getText())) {
            alert.setContentText("Date Time Format is Invalid");
            alert.showAndWait();
            return false;
        }

        LocalDateTime start = LocalDateTime.parse(startDateTF.getText(), sdf);
        LocalDateTime end = LocalDateTime.parse(endDateTF.getText(), sdf);

        //check if start date falls after end date
        if (start.isAfter(end)) {
            alert.setContentText("Start date cannot be before End date");
            alert.showAndWait();
            return false;
        }

        //checks if appointment is outside business hours
        LocalTime open = LocalTime.of(8, 0);
        LocalTime closed = LocalTime.of(22, 0);

        ZoneId etcZone = ZoneId.of("America/New_York");

        LocalTime startEct = start.atZone(ZoneId.systemDefault()).withZoneSameInstant(etcZone).toLocalDateTime().toLocalTime();
        System.out.println(startEct + " open - " + open + " close - " + closed);
        if (startEct.isBefore(open) || startEct.isAfter(closed)) {
            alert.setContentText("Start date is outside of the business hours (8:00 AM - 10:00 PM EST)");
            alert.showAndWait();
            return false;
        }

        LocalTime endEct = end.atZone(ZoneId.systemDefault()).withZoneSameInstant(etcZone).toLocalDateTime().toLocalTime();
        if (endEct.isBefore(open) || endEct.isAfter(closed)) {
            alert.setContentText("End date is outside of the business hours (8:00 AM - 10:00 PM EST)");
            alert.showAndWait();
            return false;
        }

        return true;
    }

    public boolean checkAppointmentConflicts(Appointment app) {
        List<Appointment> appointmentList = DbController.getInstance().getAppointmentListByCustomerId(app.getCustomerId());
        for (Appointment existingApp : appointmentList) {
            //in case of editing skip the same appointment id conflict check
            if (existingApp.getId() == app.getId()){
                continue;
            }

            LocalDateTime utcAppStart = app.getStart().atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneOffset.UTC).toLocalDateTime();
            LocalDateTime utcAppEnd = app.getEnd().atZone(ZoneId.systemDefault()).withZoneSameInstant(ZoneOffset.UTC).toLocalDateTime();

            if ((utcAppStart.isAfter(existingApp.getStart()) && utcAppStart.isBefore(existingApp.getEnd()))
                    || utcAppEnd.isAfter(existingApp.getStart()) && utcAppEnd.isBefore(existingApp.getEnd())) {

                //show a dialog with conflict message
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setTitle("Appointment Conflict");
                alert.setHeaderText(null);
                alert.setContentText("The appointment timing conflicts with another appointment.");
                alert.showAndWait();
                return true;
            }
        }

        return false;
    }
}
