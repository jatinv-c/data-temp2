package project.controller;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;
import project.App;
import project.model.Appointment;
import project.model.Contact;
import project.model.Customer;

import java.io.IOException;
import java.net.URL;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

/**
 * Controller for Report Screen
 */
public class ReportsController implements Initializable {

    @FXML
    private ComboBox<Contact> contactCB;

    @FXML
    private TableColumn<Appointment, String> locationTC;

    @FXML
    private TableColumn<Appointment, String> titleTC1;

    @FXML
    private Label h1;

    @FXML
    private TableColumn<Appointment, String> contactIdTC1;

    @FXML
    private TextField totalCountMonthTF;

    @FXML
    private TableColumn<Appointment, String> descriptionTC1;

    @FXML
    private TableColumn<Appointment, String> typeTC1;

    @FXML
    private TableColumn<Appointment, String> descriptionTC;

    @FXML
    private TableColumn<Appointment, String> endDateTC1;

    @FXML
    private TableColumn<Appointment, String> titleTC;

    @FXML
    private TableColumn<Appointment, String> customerIdTC1;

    @FXML
    private TableColumn<Appointment, String> appointmentIdTC1;

    @FXML
    private TableColumn<Appointment, String> appointmentIdTC;

    @FXML
    private TableColumn<Appointment, String> endDateTC;

    @FXML
    private TableColumn<Appointment, String> contactIdTC;

    @FXML
    private TableColumn<Appointment, String> userIdTC1;

    @FXML
    private TableColumn<Appointment, String> typeTC;

    @FXML
    private TableColumn<Appointment, String> locationTC1;

    @FXML
    private ComboBox<Month> monthCB;

    @FXML
    private ComboBox<Customer> customerCB;

    @FXML
    private TableColumn<Appointment, String> customerIdTC;

    @FXML
    private TableColumn<Appointment, String> userIdTC;

    @FXML
    private TableView<Appointment> appointmentTableCustomerView;

    @FXML
    private TableColumn<Appointment, String> startDateTC1;

    @FXML
    private TableView<Appointment> appointmentTableContactView;

    @FXML
    private Button backButton;

    @FXML
    private TableColumn<Appointment, String> startDateTC;

    @FXML
    private TableView<Map.Entry<String,Integer>> typeTable;

    @FXML
    private TableColumn<Map.Entry<String,Integer>, String> appointmentTypeTC;

    @FXML
    private TableColumn<Map.Entry<String,Integer>, String> appointmentCountTC;

    ObservableList<Contact> contactList;
    ObservableList<Customer> customerList;
    ObservableList<Appointment> appointmentMonthList;
    ObservableList<Appointment> appointmentContactList;
    ObservableList<Appointment> appointmentCustomerList;

    List<Appointment> appointmentList;

    ObservableList<Map.Entry<String, Integer>> appointmentTypeList;

    DateTimeFormatter sdf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /**
     * Initializes the fxml screen
     * @param url url
     * @param resourceBundle resource bundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        System.out.println("Reports opened");
        //get appointments list
        appointmentList = DbController.getInstance().getAppointmentList();

        monthCB.setItems(FXCollections.observableArrayList(Month.values()));

        //call the method to update table on combo box value change
        monthCB.getSelectionModel().selectedItemProperty().addListener((options, oldValue, newValue) -> {
            filterAppointmentByMonthAndType(newValue);
        });

        //Get contacts list
        contactList = FXCollections.observableArrayList(DbController.getInstance().getContactList());
        //Combo Box has contact object. To show only the contact name
        //create a custom factory
        Callback<ListView<Contact>, ListCell<Contact>> factory_contact = lv -> new ListCell<Contact>() {
            @Override
            protected void updateItem(Contact item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty ? "" : item.getName());
            }
        };
        //set custom factory to combo box cell factory
        contactCB.setCellFactory(factory_contact);
        //set the item of combo box to contact list
        contactCB.setItems(contactList);
        contactCB.setButtonCell(factory_contact.call(null));

        //call the method to update table on combo box value change
        contactCB.getSelectionModel().selectedItemProperty().addListener((options, oldValue, newValue) -> {
            filterAppointmentByContact(newValue);
        });

        //Get customers list
        customerList = FXCollections.observableArrayList(DbController.getInstance().getCustomerList());
        //Combo Box has contact object. To show only the contact name
        //create a custom factory
        Callback<ListView<Customer>, ListCell<Customer>> factory_customer = lv -> new ListCell<Customer>() {
            @Override
            protected void updateItem(Customer item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty ? "" : item.getCustomerId() + "");
            }
        };
        //set custom factory to combo box cell factory
        customerCB.setCellFactory(factory_customer);
        //set the item of combo box to contact list
        customerCB.setItems(customerList);
        customerCB.setButtonCell(factory_customer.call(null));

        //call the method to update table on combo box value change
        customerCB.getSelectionModel().selectedItemProperty().addListener((options, oldValue, newValue) -> {
            filterAppointmentByCustomer(newValue);
        });

        //table values for contact filter
        appointmentIdTC.setCellValueFactory(new PropertyValueFactory<>("id"));
        titleTC.setCellValueFactory(new PropertyValueFactory<>("title"));
        descriptionTC.setCellValueFactory(new PropertyValueFactory<>("description"));
        locationTC.setCellValueFactory(new PropertyValueFactory<>("location"));
        typeTC.setCellValueFactory(new PropertyValueFactory<>("type"));
        userIdTC.setCellValueFactory(new PropertyValueFactory<>("userId"));
        customerIdTC.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        contactIdTC.setCellValueFactory(new PropertyValueFactory<>("contactId"));
        //convert UTC date time to Local zone date time
        startDateTC.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getStart().atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime().format(sdf)));
        endDateTC.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getEnd().atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime().format(sdf)));

        //table values for customer filter
        appointmentIdTC1.setCellValueFactory(new PropertyValueFactory<>("id"));
        titleTC1.setCellValueFactory(new PropertyValueFactory<>("title"));
        descriptionTC1.setCellValueFactory(new PropertyValueFactory<>("description"));
        locationTC1.setCellValueFactory(new PropertyValueFactory<>("location"));
        typeTC1.setCellValueFactory(new PropertyValueFactory<>("type"));
        userIdTC1.setCellValueFactory(new PropertyValueFactory<>("userId"));
        customerIdTC1.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        contactIdTC1.setCellValueFactory(new PropertyValueFactory<>("contactId"));
        //convert UTC date time to Local zone date time
        startDateTC1.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getStart().atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime().format(sdf)));
        endDateTC1.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getEnd().atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime().format(sdf)));


        appointmentTypeTC.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getKey()));
        appointmentCountTC.setCellValueFactory(e -> new SimpleStringProperty("" + e.getValue().getValue()));
    }

    /**
     * Method called when the back button is clicked
     * @param event event
     */
    @FXML
    void onBackButtonClicked(ActionEvent event) {
        try {
            App.setRoot("Home");
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    /**
     * Method to filter appointments by given month and calculate the appointments
     * count for each type of appointment
     * @param month month to get result for
     */
    public void filterAppointmentByMonthAndType(Month month) {
        appointmentMonthList = FXCollections.observableArrayList(appointmentList.stream().filter(e -> e.getStart().getMonth() == month)
                .collect(Collectors.toList()));

        Map<String, Integer> typeCountMap = new HashMap<>();

        int totalCount = 0;

        for (int i =0; i < appointmentMonthList.size() ; i++) {
            Appointment e = appointmentMonthList.get(i);
            totalCount++;
            String type = e.getType();
            if (typeCountMap.containsKey(type)) {
                typeCountMap.put(type, typeCountMap.get(type) + 1);
            } else {
                typeCountMap.put(type, 1);
            }
        }

        appointmentTypeList = FXCollections.observableArrayList(typeCountMap.entrySet());

        typeTable.setItems(appointmentTypeList);

        totalCountMonthTF.setText(totalCount + "");
    }

    /**
     * Method to get appointments for a specified contact
     * @param contact contact to get data for
     */
    public void filterAppointmentByContact(Contact contact) {
        appointmentContactList = FXCollections.observableArrayList(appointmentList.stream().filter(e -> e.getContactId() == contact.getContactId())
                .collect(Collectors.toList()));
        appointmentTableContactView.setItems(appointmentContactList);
    }

    /**
     * Metod to filter appointments based on a customer
     * @param customer customer to get data for
     */
    public void filterAppointmentByCustomer(Customer customer) {
        appointmentCustomerList = FXCollections.observableArrayList(appointmentList.stream().filter(e -> e.getCustomerId() == customer.getCustomerId())
                .collect(Collectors.toList()));
        appointmentTableCustomerView.setItems(appointmentCustomerList);
    }
}
