package project.controller;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import project.App;
import project.model.Appointment;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

/**
 * Controller for Appointments screen
 */
public class AppointmentsController implements Initializable {

    @FXML
    private TableColumn<Appointment, String> contactIdTC;

    @FXML
    private ToggleGroup rb1;

    @FXML
    private RadioButton monthlyAppointRadio;

    @FXML
    private TableColumn<Appointment, String> locationTC;

    @FXML
    private Button deleteButton;

    @FXML
    private RadioButton weeklyAppointRadio;

    @FXML
    private RadioButton allAppointRadio;

    @FXML
    private TableColumn<Appointment, String> typeTC;

    @FXML
    private Button addButton;

    @FXML
    private TableColumn<Appointment, String> customerIdTC;

    @FXML
    private TableColumn<Appointment, String> userIdTC;

    @FXML
    private TableColumn<Appointment, String> descriptionTC;

    @FXML
    private Label scheduleLabel;

    @FXML
    private TableColumn<Appointment, String> titleTC;

    @FXML
    private Button editButton;

    @FXML
    private Button backButton;

    @FXML
    private TableColumn<Appointment, String> appointmentIdTC;

    @FXML
    private Label filterLabel;

    @FXML
    private TableView<Appointment> appointmentTableView;

    @FXML
    private TableColumn<Appointment, String> startDateTC;

    @FXML
    private TableColumn<Appointment, String> endDateTC;

    enum FiltersEnum {
        All, Weekly, Monthly
    }

    ObservableList<Appointment> appointmentsList;

    DateTimeFormatter sdf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    FiltersEnum filter;

    /**
     * Initializes the fxml screen
     * @param url url
     * @param resourceBundle resource bundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        appointmentIdTC.setCellValueFactory(new PropertyValueFactory<>("id"));
        titleTC.setCellValueFactory(new PropertyValueFactory<>("title"));
        descriptionTC.setCellValueFactory(new PropertyValueFactory<>("description"));
        locationTC.setCellValueFactory(new PropertyValueFactory<>("location"));
        typeTC.setCellValueFactory(new PropertyValueFactory<>("type"));
        userIdTC.setCellValueFactory(new PropertyValueFactory<>("userId"));
        customerIdTC.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        contactIdTC.setCellValueFactory(new PropertyValueFactory<>("contactId"));
        //convert UTC date time to Local zone date time
        startDateTC.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getStart().atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime().format(sdf)));
        endDateTC.setCellValueFactory(e -> new SimpleStringProperty(e.getValue().getEnd().atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime().format(sdf)));

        filter = FiltersEnum.All;

        updateTableData();
    }

    /**
     * Method that is called when user clicks on Add button
     * @param event event
     */
    @FXML
    void onAddButtonClicked(ActionEvent event) {
        AppointmentInformationController.newAppointmentId = DbController.getInstance().getMaxAppointmentId() + 1;
        AppointmentInformationController.editMode = false;
        openAppointmentInformationScreen();
    }

    /**
     * Method that is called when user clicks on Edit button
     * @param event event
     */
    @FXML
    void onEditButtonClicked(ActionEvent event) {
        Appointment app = appointmentTableView.getSelectionModel().getSelectedItem();

        if (app == null) {
            showInfoAlert("No appointment selected!!");
            return;
        }

        AppointmentInformationController.appointment = app;
        AppointmentInformationController.editMode = true;
        openAppointmentInformationScreen();
    }

    /**
     * Method that is called when user clicks on Delete button
     * @param event event
     */
    @FXML
    void onDeleteButtonClicked(ActionEvent event) {
        Appointment app = appointmentTableView.getSelectionModel().getSelectedItem();
        if (appointmentTableView.getSelectionModel().getSelectedItem() == null) {
            showInfoAlert("No appointment selected!!");
            return;
        }

        int id = app.getId();
        DbController.getInstance().deleteAppointment(id);
        updateTableData();
        showInfoAlert("Appointment data successfully deleted!!");
    }

    /**
     * Method that is called when user clicks on Back button
     * @param event event
     */
    @FXML
    void onBackButtonClicked(ActionEvent event) {
        try {
            App.setRoot("Home");
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    /**
     * Updates the global filter to 'All' and calls the updateTableData() method
     * @param event event
     */
    @FXML
    void showAllAppointment(ActionEvent event) {
        filter = FiltersEnum.All;
        updateTableData();
    }

    /**
     * Updates the global filter to 'Weekly' and calls the updateTableData() method
     * @param event event
     */
    @FXML
    void showWeeklyAppointments(ActionEvent event) {
        filter = FiltersEnum.Weekly;
        updateTableData();
    }

    /**
     * Updates the global filter to 'Monthly' and calls the updateTableData() method
     * @param event event
     */
    @FXML
    void showMonthlyAppointments(ActionEvent event) {
        filter = FiltersEnum.Monthly;
        updateTableData();
    }

    /**
     * Method to open appointment details window where user can add/edit appointment
     */
    public void openAppointmentInformationScreen() {
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/project/view/AppointmentInformation.fxml"));
        try {
            Scene scene = new Scene(fxmlLoader.load());
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(backButton.getScene().getWindow());
            stage.setTitle("Customer Information");
            stage.setScene(scene);
            stage.showAndWait();

            updateTableData();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to update the appointment data in table after an add, edit or delete operation
     * The method checks which filter option is selected and based on it filters and
     * show the appointments in the table
     */
    public void updateTableData() {

        //get the latest appointments list
        appointmentsList = FXCollections.observableArrayList(DbController.getInstance().getAppointmentList());

        ObservableList appointmentsToShowList = null;

        if (filter.equals(FiltersEnum.Weekly)) {
            appointmentsToShowList = appointmentsList.stream()
                    .filter(e -> e.getStart().atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime().isAfter(LocalDateTime.now())
                            && e.getStart().atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime().isBefore(LocalDateTime.now().plusWeeks(1)))
                    .collect(Collectors.toCollection(FXCollections::observableArrayList));
        } else if (filter.equals(FiltersEnum.Monthly)) {
            appointmentsToShowList = appointmentsList.stream()
                    .filter(e -> e.getStart().atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime().isAfter(LocalDateTime.now())
                            && e.getStart().atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime().isBefore(LocalDateTime.now().plusMonths(1)))
                    .collect(Collectors.toCollection(FXCollections::observableArrayList));
        }else {
            appointmentsToShowList = appointmentsList;
        }

        //set the data in table
        appointmentTableView.setItems(appointmentsToShowList);
    }

    /**
     * Method to show a message dialog box
     * @param msg Message to display in the dialog
     */
    public void showInfoAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setTitle("Success!!");
        alert.setContentText(msg);
        alert.showAndWait();
    }


}
