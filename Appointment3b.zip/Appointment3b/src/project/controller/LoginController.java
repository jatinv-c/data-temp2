package project.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import project.App;

import java.io.IOException;
import java.net.URL;
import java.time.ZoneId;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Controller for Login screen
 */
public class LoginController implements Initializable {

    @FXML
    private TextField userIdTF;

    @FXML
    private ToggleGroup languageToggleGroup;

    @FXML
    private Button loginButton;

    @FXML
    private PasswordField passwordTF;

    @FXML
    private Label locationLabel;

    @FXML
    private Label label;

    @FXML
    private RadioButton freRB;

    @FXML
    private Label locationDispLabel;

    @FXML
    private RadioButton engRB;

    @FXML
    private Label formHeading;

    @FXML
    private Label userIdLabel;

    @FXML
    private Label passwordLabel;

    private String successMsg = "";
    private String validationMsg = "";
    private String errorMsg = "";
    private String alertTitle = "";
    private String alertWrongTitle = "";

    /**
     * Initializes the fxml screen
     *
     * @param url            url
     * @param resourceBundle resource bundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        ZoneId zone = ZoneId.systemDefault();
        locationLabel.setText(zone + "");

        Locale systemLocale = Locale.getDefault();
        setLocalizedText(systemLocale);
    }

    /**
     * Method which gets called when english language radio button is selected
     *
     * @param event event
     */
    @FXML
    void onEnglishSelected(ActionEvent event) {
        setLocalizedText(new Locale("en"));
    }

    /**
     * Method which gets called when french language radio button is selected
     *
     * @param event event
     */
    @FXML
    void onFrenchSelected(ActionEvent event) {
        setLocalizedText(new Locale("fr"));
    }

    /**
     * Method which gets called when login button is clicked
     *
     * @param event event
     */
    @FXML
    void onLoginBtnClicked(ActionEvent event) {
        System.out.println("Button Clicked");
        if (validateForm()) {
            try {
                System.out.println("Validation passed");
                String username = userIdTF.getText();
                String password = passwordTF.getText();
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setHeaderText(null);
                if (DbController.getInstance().validateUser(username, password)) {
                    alert.setTitle(alertTitle);
                    alert.setContentText(successMsg);
                    alert.showAndWait();

                    //show main window on successful login
                    App.setRoot("Home");
                    HomeController.checkUpcomingAppointment();
                } else {
                    alert.setTitle(alertWrongTitle);
                    alert.setContentText(errorMsg);
                    alert.showAndWait();
                }
            } catch (IOException ex) {
                System.out.println(ex);
            }
        }
    }

    /**
     * Method to set the selected language text to form elements
     *
     * @param locale specifies the language to be set
     */
    private void setLocalizedText(Locale locale) {
        ResourceBundle bundle = ResourceBundle.getBundle("project/localization/localization", locale);
        formHeading.setText(bundle.getString("formHeading"));
        userIdLabel.setText(bundle.getString("userNameLabel"));
        passwordLabel.setText(bundle.getString("passwordLabel"));
        locationDispLabel.setText(bundle.getString("locationLabel"));
        loginButton.setText(bundle.getString("loginButton"));
        successMsg = bundle.getString("successMessage");
        errorMsg = bundle.getString("errorMessage");
        validationMsg = bundle.getString("validationMsg");
        alertTitle = bundle.getString("alertCorrectTitle");
        alertWrongTitle = bundle.getString("alertWrongTitle");
    }

    /**
     * Validates the form input
     *
     * @return true if correctly validated, false otherwise
     */
    private boolean validateForm() {

        if (userIdTF.getText().isEmpty() || passwordTF.getText().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Validation Error");
            alert.setContentText(validationMsg);
            alert.showAndWait();
            return false;
        }
        return true;
    }
}

