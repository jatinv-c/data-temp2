package project.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import project.App;
import project.model.Country;
import project.model.Customer;
import project.model.Division;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * Controller for Customer fxml
 */
public class CustomerController implements Initializable {

    @FXML
    private TextField nameTF;

    @FXML
    private Button deleteButton;

    @FXML
    private TableColumn<?, ?> addressCol;

    @FXML
    private TextField addressTF;

    @FXML
    private TableView<Customer> customerTable;

    @FXML
    private Label h1;

    @FXML
    private Label addressLabel;

    @FXML
    private TableColumn<Customer, String> countryCol;

    @FXML
    private Label phoneLabel;

    @FXML
    private Label divisionLabel;

    @FXML
    private TableColumn<Customer, String> customerNameCol;

    @FXML
    private TableColumn<Customer, String> divisionCol;

    @FXML
    private Button backButton;

    @FXML
    private Label nameLabel;

    @FXML
    private TextField phoneNoTF;

    @FXML
    private TableColumn<Customer, String> customerIDCol;

    @FXML
    private Button addButton;

    @FXML
    private ComboBox<Country> countryCB;

    @FXML
    private TableColumn<Customer, String> postalCodeCol;

    @FXML
    private TextField customerIdTF;

    @FXML
    private Label customerIdLabel;

    @FXML
    private Button editButton;

    @FXML
    private Label coutryLabel;

    @FXML
    private TableColumn<Customer, String> phoneNumberCol;

    @FXML
    private Label postalLabel;

    @FXML
    private TextField postalCodeTF;

    @FXML
    private ComboBox<Division> divisionCB;

    ObservableList<Customer> customerList;

    /**
     * Initializes the fxml screen
     * @param url url
     * @param resourceBundle resource bundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        customerIDCol.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        customerNameCol.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        postalCodeCol.setCellValueFactory(new PropertyValueFactory<>("postalCode"));
        phoneNumberCol.setCellValueFactory(new PropertyValueFactory<>("phone"));
        addressCol.setCellValueFactory(new PropertyValueFactory<>("address"));
        divisionCol.setCellValueFactory(new PropertyValueFactory<>("divisionId"));

        updateCustomerData();
    }

    /**
     * Method that is called when user clicks on Add button
     * @param event event
     */
    @FXML
    void onAddButtonClicked(ActionEvent event) {
        CustomerInformationController.newCustomerId = DbController.getInstance().getMaxCustomerId() + 1;
        CustomerInformationController.editMode = false;
        openCustomerInformationScreen();
    }

    /**
     * Method that is called when user clicks on Edit button
     * @param event event
     */
    @FXML
    void onEditButtonClicked(ActionEvent event) {
        Customer cust = customerTable.getSelectionModel().getSelectedItem();

        //check if any customer is selected or not
        if (cust == null){
            showInfoAlert("No customer selected!!");
            return;
        }

        CustomerInformationController.customer = cust;
        CustomerInformationController.editMode = true;
        openCustomerInformationScreen();
    }

    /**
     * Method that is called when user clicks on Delete button
     * @param event event
     */
    @FXML
    void onDeleteButtonClicked(ActionEvent event) {
        Customer cust = customerTable.getSelectionModel().getSelectedItem();

        //check if any customer is selected or not
        if (cust == null){
            showInfoAlert("No customer selected!!");
            return;
        }

        int id = cust.getCustomerId();
        DbController.getInstance().deleteCustomer(id);
        updateCustomerData();
        showInfoAlert("Customer data successfully deleted!!");
    }

    /**
     * Method that is called when user clicks on Back button
     * @param event event
     */
    @FXML
    void onBackButtonClicked(ActionEvent event) {
        try {
            App.setRoot("Home");
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    /**
     * Method to open customer details window where user can add/edit customers
     */
    public void openCustomerInformationScreen(){
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/project/view/CustomerInformation.fxml"));
        try {
            Scene scene = new Scene(fxmlLoader.load());
            stage.initModality(Modality.WINDOW_MODAL);
            stage.initOwner(backButton.getScene().getWindow());
            stage.setTitle("Customer Information");
            stage.setScene(scene);
            stage.showAndWait();

            updateCustomerData();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Method to update the customer data in table after an add, edit or delete operation
     */
    public void updateCustomerData(){
        //Get Customer list
        customerList = FXCollections.observableArrayList(DbController.getInstance().getCustomerList());

        //add the data to table
        customerTable.setItems(customerList);
    }

    /**
     * Method to show a message dialog box
     * @param msg Message to display in the dialog
     */
    public void showInfoAlert(String msg){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setTitle("Success!!");
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
