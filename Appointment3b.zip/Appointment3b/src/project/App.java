package project;

import javafx.scene.Node;
import project.controller.AppointmentsController;
import project.controller.CustomerController;
import project.controller.HomeController;
import project.model.User;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDateTime;

public class App extends Application {

    private static Scene scene;

    public static User currentUser;

    /**
     * This function is called when the FXML app starts
     *
     * @param stage Primary stage
     * @throws Exception throws Exception
     */
    @Override
    public void start(Stage stage) throws Exception {
//        Parent root = FXMLLoader.load(getClass().getResource("view/Login.fxml"));
        scene = new Scene(loadFXML("Login"), 1200, 540);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Method to set the selected fxml to the main window
     * @param fxml fxml file to load
     * @throws IOException if specified fxml file is not found
     */
    public static void setRoot(String fxml) throws  IOException{
        Parent parent = loadFXML(fxml);
        scene.setRoot(parent);
    }

    /**
     * Method to load fxml and return the parent
     * @param fxml fxml to load
     * @return Parent object which contains the loaded fxml window
     * @throws IOException
     */
    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource("/project/view/" + fxml + ".fxml"));
        return fxmlLoader.load();
    }

    /**
     * Main method of the application - starting point
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
