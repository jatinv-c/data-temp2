package model;

/**
 * This Class stores first level divisions information
 *
 */
public class Division {

    private String divisionID, divisionName, countryID;

    /**
     * parametric constructor to initialize variables
     *
     * @param divisionID Division id
     * @param divisionName Name of division
     * @param countryID country id
     */
    public Division(String divisionID, String divisionName, String countryID) {
        this.divisionID = divisionID;
        this.divisionName = divisionName;
        this.countryID = countryID;
    }

    public String getDivisionID() {
        return divisionID;
    }

    public String getCountryID() {
        return countryID;
    }

    public void setCountryID(String countryID) {
        this.countryID = countryID;
    }

    public void setDivisionID(String divisionID) {
        this.divisionID = divisionID;
    }

    public String getDivisionName() {
        return divisionName;
    }

    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }

    @Override
    public String toString() {
        return "Division{" + "divisionID=" + divisionID + ", divisionName=" + divisionName + ", countryID=" + countryID + '}';
    }

}
