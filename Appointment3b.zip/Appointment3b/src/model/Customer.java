package model;

/**
 * This Class stores customers information
 *
 */
public class Customer {

    //declaring attributes
    private String customerID, customerName, postalCode, phoneNumber, address, country, division;

    /**
     * parametric constructor to initialize variables
     *
     * @param customerID - id of customer
     * @param customerName - name of customer
     * @param postalCode - postal code
     * @param phoneNumber - phone number
     * @param address - address
     * @param country - country
     * @param division - customer division
     */
    public Customer(String customerID, String customerName, String postalCode, String phoneNumber, String address, String country, String division) {
        this.customerID = customerID;
        this.customerName = customerName;
        this.postalCode = postalCode;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.country = country;
        this.division = division;
    }

    //getter and setter methods
    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }


    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }


    @Override
    public String toString() {
        return "Customer{" + "customerID=" + customerID + ", customerName=" + customerName + ", postalCode=" + postalCode + ", phoneNumber=" + phoneNumber + ", address=" + address + ", country=" + country + ", division=" + division + '}';
    }

}
