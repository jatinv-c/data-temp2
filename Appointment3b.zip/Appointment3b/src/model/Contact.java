package model;

/**
 * This Class contains contact details
 *
 * @author PC
 */
public class Contact {

    private String contactID, contactName, contactEmail;

    /**
     * The constructor initialize all values for contact
     *
     * @param contactID stores ID of Contact
     * @param contactName stores name of Contact
     * @param contactEmail stores email of Contact
     */
    public Contact(String contactID, String contactName, String contactEmail) {
        this.contactID = contactID;
        this.contactName = contactName;
        this.contactEmail = contactEmail;
    }

    public String getContactID() {
        return contactID;
    }

    public void setContactID(String contactID) {
        this.contactID = contactID;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    @Override
    public String toString() {
        return "Contact{" + "contactID=" + contactID + ", contactName=" + contactName + ", contactEmail=" + contactEmail + '}';
    }

}
