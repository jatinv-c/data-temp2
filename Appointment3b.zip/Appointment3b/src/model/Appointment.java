/**
 * <h1>Appointment class!</h1>
 * This Class saves details for Appointments
 *
 * <p>
 * @author PC
 */
package model;

import javafx.beans.property.SimpleObjectProperty;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 *
 * This Class holds appointment records
 */
public class Appointment {

    /**
     * Declaring Class Attributes
     */
    private String contactID, appointmentID, title, description, location, type, customerID, userID;
    private LocalDateTime startDate, endDate;

    /**
     * Parameterized Constructor for setting Appointment values
     * @param contactID - contact id
     * @param appointmentID - appointment id
     * @param title - title
     * @param description - description
     * @param location - location
     * @param type - type
     * @param startDate - start date of appointment
     * @param endDate - end date of appointment
     * @param customerID - customer id
     * @param userID - user id who created the appointment
     */
    public Appointment(String contactID, String appointmentID, String title, String description, String location, String type, LocalDateTime startDate, LocalDateTime endDate, String customerID, String userID) {

        this.appointmentID = appointmentID;
        this.title = title;
        this.description = description;
        this.location = location;
        this.contactID = contactID;
        this.type = type;
        this.startDate = startDate;
        this.endDate = endDate;
        this.customerID = customerID;
        this.userID = userID;
    }

    public String getAppointmentID() {
        return appointmentID;
    }

    public void setAppointmentID(String appointmentID) {
        this.appointmentID = appointmentID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public String getContactID() {
        return contactID;
    }

    public void setContactID(String contactID) {
        this.contactID = contactID;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    @Override
    public String toString() {
        return "Appointment{" + "contactID=" + contactID + ", appointmentID=" + appointmentID + ", title=" + title + ", description=" + description + ", location=" + location + ", type=" + type + ", startDate=" + startDate + ", endDate=" + endDate + ", customerID=" + customerID + ", userID=" + userID + '}';
    }

}
