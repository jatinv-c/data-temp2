package model;

import java.sql.Timestamp;

/**
 * This Class contains specific appointment details
 *
 * @author pc
 */
public class AppointmentDetails {

    private String appointmentID, title, description, type, customerID;
    private Timestamp startDate, endDate;

    /**
     *Parameterized Constructor for setting Appointment values
     * @param appointmentID - appointment id
     * @param title - title
     * @param description - description
     * @param type - type of appointment
     * @param startDate - start date of appointment
     * @param endDate - end date of appointment
     * @param customerID - user id who created the appointment
     */

    public AppointmentDetails(String appointmentID, String title, String description, String type, Timestamp startDate, Timestamp endDate, String customerID) {
        this.appointmentID = appointmentID;
        this.title = title;
        this.description = description;
        this.type = type;
        this.startDate = startDate;
        this.endDate = endDate;
        this.customerID = customerID;
    }

    public String getAppointmentID() {
        return appointmentID;
    }

    public void setAppointmentID(String appointmentID) {
        this.appointmentID = appointmentID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Timestamp getStartDate() {
        return startDate;
    }

    public void setStartDate(Timestamp startDate) {
        this.startDate = startDate;
    }

    public Timestamp getEndDate() {
        return endDate;
    }

    public void setEndDate(Timestamp endDate) {
        this.endDate = endDate;
    }

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    @Override
    public String toString() {
        return "AppointmentDetails{" +
                "appointmentID='" + appointmentID + '\'' +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", type='" + type + '\'' +
                ", startDate='" + startDate + '\'' +
                ", endDate='" + endDate + '\'' +
                ", customerID='" + customerID + '\'' +
                '}';
    }
}
