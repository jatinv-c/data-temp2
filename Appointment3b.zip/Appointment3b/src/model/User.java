package model;

/**
 * This Class stores users information
 *
 */
public class User {

    private String userID,userName, userPassword;

    /**
     * Parametric Constructor initialize class variables
     *
     * @param userID - id for the user
     * @param userName - user name
     * @param userPassword - user password
     */
    public User(String userID, String userName, String userPassword) {
        this.userID = userID;
        this.userName = userName;
        this.userPassword = userPassword;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    @Override
    public String toString() {
        return "User{" + "userID=" + userID + ", userName=" + userName + ", userPassword=" + userPassword + '}';
    }

}
