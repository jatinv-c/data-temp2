package model;

/**
 * This Class stores counties information
 */
public class Country {

    private String countryID, countryName;

    /**
     * parametric constructor to initialize variables
     *
     * @param countryID - country id
     * @param countryName - name of country
     */

    public Country(String countryID, String countryName) {
        this.countryID = countryID;
        this.countryName = countryName;
    }

    public String getCountryID() {
        return countryID;
    }

    public void setCountryID(String countryID) {
        this.countryID = countryID;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    @Override
    public String toString() {
        return "Country{" + "countryID=" + countryID + ", countryName=" + countryName + '}';
    }

}
