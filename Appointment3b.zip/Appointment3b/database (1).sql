-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2022 at 08:46 PM
-- Server version: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `Appointment_ID` int(10) NOT NULL,
  `Title` varchar(50) NOT NULL,
  `Description` varchar(50) NOT NULL,
  `Location` varchar(50) NOT NULL,
  `Type` varchar(50) NOT NULL,
  `Start` datetime NOT NULL,
  `End` datetime NOT NULL,
  `Create_Date` datetime NOT NULL,
  `Created_By` varchar(50) NOT NULL,
  `Last_Update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Last_Updated_By` varchar(50) NOT NULL,
  `Customer_ID` int(10) NOT NULL,
  `User_ID` int(10) NOT NULL,
  `Contact_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `Contact_ID` int(50) NOT NULL,
  `Contact_Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`Contact_ID`, `Contact_Name`, `Email`) VALUES
(111, 'name1', 'email@gmail.com'),
(222, 'name2', 'email@gmail.com'),
(333, 'name3', 'email@gmail.com'),
(444, 'name4', 'email@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `Country_ID` int(50) NOT NULL,
  `Country` varchar(50) NOT NULL,
  `create_Date` datetime NOT NULL,
  `Created_By` varchar(50) NOT NULL,
  `Last_Update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Last_Updated_By` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`Country_ID`, `Country`, `create_Date`, `Created_By`, `Last_Update`, `Last_Updated_By`) VALUES
(1, 'US', '2022-05-10 00:01:00', 'admin', '2022-05-21 23:10:11', 'admin'),
(2, 'UK', '2022-05-04 05:09:07', 'admin', '2022-05-16 21:06:05', 'admin'),
(3, 'Canada', '2022-05-03 03:08:05', 'admin', '2022-05-18 23:10:13', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_Id` int(50) NOT NULL,
  `Customer_Name` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Postal_Code` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `create_Date` datetime NOT NULL,
  `Created_By` varchar(50) NOT NULL,
  `Last_Update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Last_Updated_By` varchar(50) NOT NULL,
  `Division_ID` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `first_level_division`
--

CREATE TABLE `first_level_division` (
  `Division_ID` varchar(50) NOT NULL,
  `Division` varchar(50) NOT NULL,
  `Create_Date` varchar(50) NOT NULL,
  `Created_By` varchar(50) NOT NULL,
  `Last_Update` varchar(100) NOT NULL,
  `Last_Updated_By` varchar(50) NOT NULL,
  `Country_ID` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `first_level_division`
--

INSERT INTO `first_level_division` (`Division_ID`, `Division`, `Create_Date`, `Created_By`, `Last_Update`, `Last_Updated_By`, `Country_ID`) VALUES
('11', 'California', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 1),
('12', 'Texas', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 1),
('13', 'Florida', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 1),
('14', 'Washington', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 1),
('15', 'Alaska', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 1),
('16', 'Hawaii', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 1),
('17', 'Virginia', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 1),
('18', 'Georgia', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 1),
('19', 'Montana', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 1),
('20', 'Arizona', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 1),
('21', 'London', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 2),
('22', 'Birmingham', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 2),
('23', 'Bristol', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 2),
('24', 'Manchester', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 2),
('25', 'Glasgow', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 2),
('26', 'LiverPool', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 2),
('27', 'York', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 2),
('28', 'NewCastle', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 2),
('29', 'Cardiff', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 2),
('30', 'Derby', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 2),
('31', 'Toronto', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 3),
('32', 'Quebec City', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 3),
('33', 'Montreal', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 3),
('34', 'Vancouver', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 3),
('35', 'Ottawa', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 3),
('36', 'Winnipeg', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 3),
('37', 'Victoria', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 3),
('38', 'Hamilton', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 3),
('39', 'Regina', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 3),
('40', 'Kingstone', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin', 3);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `User_ID` varchar(50) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Create_Date` varchar(50) NOT NULL,
  `Created_By` varchar(100) NOT NULL,
  `Last_Update` varchar(50) NOT NULL,
  `Last_Updated_By` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`User_ID`, `UserName`, `Password`, `Create_Date`, `Created_By`, `Last_Update`, `Last_Updated_By`) VALUES
('444', 'username1', 'password1', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin'),
('445', 'username2', 'password2', '19/05/2022 10:14:00', 'admin', '19/05/2022 10:14:00', 'admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
