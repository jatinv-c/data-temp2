package project.pdfcard3;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javax.imageio.ImageIO;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/**
 * FXML Controller class
 *
 * @author Work
 */
public class HomeController implements Initializable {

    @FXML
    private Button frontTempButton;
    @FXML
    private Button startButton;
    @FXML
    private Button insideTempButton;
    @FXML
    private Button sourceButton;
    @FXML
    private Label infoLabel;
    @FXML
    private ProgressBar progress;
    @FXML
    private TextField frontTF;
    @FXML
    private TextField insideTF;
    @FXML
    private TextField sourceTF;
    @FXML
    private TextField destinationFolderTF;
    @FXML
    private Button destinationFolderButton;
    @FXML
    private TextField frontBatchTF;
    @FXML
    private Button frontBatchButton;
    @FXML
    private TextField insideBatchTF;
    @FXML
    private Button insideBatchButton;

    private final String FRONT_PDF_DIR = "front";
    private final String INSIDE_PDF_DIR = "inside";

    BufferedImage outiseImageTemplate;
    BufferedImage insideImageTemplate;
    File frontTemplateFile;
    File insideTemplateFile;
    File sourceFile;
    File frontBatchFile;
    File insideBatchFile;
    File destinationFolder;
    AtomicBoolean isCompleted;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        infoLabel.setVisible(false);
        progress.setVisible(false);
        frontTF.setEditable(false);
        insideTF.setEditable(false);
        sourceTF.setEditable(false);
    }

    @FXML
    private void frontTempButtonClicked(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Front Template File");
        fileChooser.setInitialDirectory(new File("."));
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("PNG", "*.png"),
                new FileChooser.ExtensionFilter("JPG", "*.jpg"),
                new FileChooser.ExtensionFilter("JPEG", "*.jpeg")
        );
        File file = fileChooser.showOpenDialog(((Node) event.getSource()).getScene().getWindow());
        if (file != null) {

            try {
                //frontImage = ImageIO.read(file);
                frontTemplateFile = file;
                frontTF.setText(file.getPath());
            } catch (Exception ex) {
                Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @FXML
    private void onStartButtonClicked(ActionEvent event) {
        if (!isValid()) {
            return;
        }

        try {
            Files.createDirectories(Paths.get(destinationFolder + File.separator + FRONT_PDF_DIR));
            Files.createDirectories(Paths.get(destinationFolder + File.separator + INSIDE_PDF_DIR));
        } catch (IOException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }

        isCompleted = new AtomicBoolean(false);

        startButton.setDisable(true);

        progress.setVisible(true);

        progress.setProgress(ProgressBar.INDETERMINATE_PROGRESS);

        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                try {
//                    Thread.sleep(5000);

                    List<String[]> data = getDataFromCsvFile(sourceFile);

                    PDDocument pdfDocFrontBatch = new PDDocument();
                    PDDocument pdfDocInsideBatch = new PDDocument();

                    for (int i = 1; i < data.size(); i++) {

                        try {

                            outiseImageTemplate = ImageIO.read(frontTemplateFile);
                            insideImageTemplate = ImageIO.read(insideTemplateFile);

                            String orderId = data.get(i)[0];

                            String noOfLineItems = data.get(i)[1];
                            
                            System.out.println(data.get(i)[2]);

                            String[] arr = data.get(i)[2].split(",");

                            String front_url = arr[arr.length - 3];

                            String inside_url = arr[arr.length - 2];

//                            String value = arr[1];
//
//                            String[] valueArr = value.split(",");
//
//                            String front_url = valueArr[valueArr.length - 3];                           
//
//                            String inside_url = valueArr[valueArr.length - 2];
                            Platform.runLater(() -> {
                                infoLabel.setVisible(true);
                                infoLabel.setText("Creating PDF for id : " + orderId);
                            });

                            BufferedImage image = ImageIO.read(new URL(front_url));

                            //get front image
                            int xExt = 48;
                            int yExt = 48;
                            int widthExt = 1156;
                            int heightExt = 1156;
                            BufferedImage frontExtractedImage = image.getSubimage(xExt, yExt, widthExt, heightExt);

                            //create front page and pdf
                            Graphics g = outiseImageTemplate.getGraphics(); //get front template                        

                            Font font = new Font("Arial", Font.PLAIN, 45);
                            g.setFont(font);
                            g.setColor(Color.BLACK);

                            int x = 1252;
                            int y = 24;
                            int width = 1156;
                            int height = 1156;
                            g.drawImage(frontExtractedImage, x, y, width, height, null);

                            g.drawString(orderId, 120, 1093);
                            g.drawString(noOfLineItems, 120, 1140);

                            g.dispose();

                            PDDocument pdfDoc = new PDDocument();

                            PDRectangle r = new PDRectangle(outiseImageTemplate.getWidth(), outiseImageTemplate.getHeight());

                            PDPage page = new PDPage(r);

                            pdfDoc.addPage(page);

                            WritableRaster raster = image.getRaster();

                            File tempFile = new File("front-temp.png");

                            ImageIO.write(outiseImageTemplate, "png", tempFile);

                            PDImageXObject pdImage = PDImageXObject.createFromFileByContent(tempFile, pdfDoc);

                            PDPageContentStream contentStream = new PDPageContentStream(pdfDoc, page);

                            contentStream.drawImage(pdImage, 0, 0);

                            contentStream.close();

                            pdfDoc.save(new File(destinationFolder + File.separator + FRONT_PDF_DIR + File.separator + "Outside [" + orderId + "].pdf"));

                            pdfDoc.close();

                            //for batch - front
                            PDRectangle rectangleFront = new PDRectangle(outiseImageTemplate.getWidth(), outiseImageTemplate.getHeight());

                            PDPage pageFront = new PDPage(rectangleFront);

                            pdfDocFrontBatch.addPage(pageFront);

                            PDImageXObject pdImageFront = PDImageXObject.createFromFileByContent(tempFile, pdfDocFrontBatch);

                            PDPageContentStream contentStreamFront = new PDPageContentStream(pdfDocFrontBatch, pageFront);

                            contentStreamFront.drawImage(pdImageFront, 0, 0);

                            contentStreamFront.close();

                            pdfDocFrontBatch.save(frontBatchFile);

                            tempFile.delete();

                            //get inside image from url
                            image = ImageIO.read(new URL(inside_url));

                            //get inside image
                            //coordinates are same
                            BufferedImage insideExtractedImage = image.getSubimage(xExt, yExt, widthExt, heightExt);

                            //create front page and pdf
                            g = insideImageTemplate.getGraphics(); //get inside template                                               

                            font = new Font("Arial", Font.BOLD, 36);
                            g.setFont(font);
                            g.setColor(Color.BLACK);

                            g.drawImage(insideExtractedImage, x, y, width, height, null);

                            g.drawString(orderId, 120, 1234);
                            
                            //calculate x position so any width text finishes at specific y position
                            FontMetrics metrics = g.getFontMetrics(font);
                            int positionX = insideImageTemplate.getWidth() - 98 - metrics.stringWidth(noOfLineItems);
                            g.drawString(noOfLineItems, positionX, 1234);

                            g.dispose();

                            pdfDoc = new PDDocument();

                            r = new PDRectangle(insideImageTemplate.getWidth(), insideImageTemplate.getHeight());
                            page = new PDPage(r);
                            pdfDoc.addPage(page);

                            raster = image.getRaster();

                            tempFile = new File("temp.png");

                            ImageIO.write(insideImageTemplate, "png", tempFile);

                            pdImage = PDImageXObject.createFromFileByContent(tempFile, pdfDoc);

                            contentStream = new PDPageContentStream(pdfDoc, page);

                            contentStream.drawImage(pdImage, 0, 0);

                            contentStream.close();

                            pdfDoc.save(new File(destinationFolder + File.separator + INSIDE_PDF_DIR + File.separator + "Insisde [" + orderId + "].pdf"));

                            pdfDoc.close();

                            //for batch - inside
                            PDRectangle rectangleInside = new PDRectangle(insideImageTemplate.getWidth(), insideImageTemplate.getHeight());

                            PDPage pageInside = new PDPage(rectangleInside);

                            pdfDocInsideBatch.addPage(pageInside);

                            PDImageXObject pdImageInside = PDImageXObject.createFromFileByContent(tempFile, pdfDocInsideBatch);

                            PDPageContentStream contentStreamInside = new PDPageContentStream(pdfDocInsideBatch, pageInside);

                            contentStreamInside.drawImage(pdImageInside, 0, 0);

                            contentStreamInside.close();

                            pdfDocInsideBatch.save(insideBatchFile);

                            tempFile.delete();

                        } catch (Exception e) {
                            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, e);
                        }
                    }

                    pdfDocFrontBatch.close();

                    Platform.runLater(() -> {
                        infoLabel.setText("Finished");
                    });

                    isCompleted.set(true);
                } catch (Exception ex) {
                    Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        };

        Thread executionThread = new Thread(runnable);
        executionThread.start();

        Thread completionCheckThread = new Thread(new Runnable() {
            @Override
            public void run() {
                while (!isCompleted.get()) {
                    //wait till execution is completed
                }
                Platform.runLater(() -> {
                    progress.setProgress(100);

                    startButton.setDisable(false);
                });
            }
        });
        //completionCheckThread.setDaemon(true);
        completionCheckThread.start();

    }

    private List<String[]> getDataFromFile(File file) {

        List<String[]> data = new ArrayList<>();

        try {

            //workbook is used so that both xls and xlsx file formats can be accepted
            Workbook wb = WorkbookFactory.create(file);

            Sheet sheetAt = wb.getSheetAt(0);

            for (Row row : sheetAt) {
                if (row.getRowNum() == 0) {
                    continue;
                }

                String arr[] = new String[3];
                arr[0] = row.getCell(0).getNumericCellValue() + "";
                arr[1] = row.getCell(1).getNumericCellValue() + "";
                arr[2] = row.getCell(2).getStringCellValue();
                data.add(arr);
            }

            wb.close();
        } catch (IOException ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }
    
    private List<String[]> getDataFromCsvFile(File file) {
        List<String[]> data = new ArrayList<>();

        try(BufferedReader br = new BufferedReader(new FileReader(file))){

            String line = "";
            
            int i = 0;
            
            while ((line = br.readLine()) != null) {    
                
//                if (i == 0) {
//                    i++;
//                    continue;
//                }
                
                String[] temp = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
                for (String string : temp) {
                    System.out.println(string);
                }
                System.out.println("--------------------------------------");
                String arr[] = new String[3];
                arr[0] = temp[0];
                arr[1] = temp[1];
                arr[2] = temp[2];
                
                data.add(arr);                
            }
            
        } catch (Exception ex) {
            Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
        }

        return data;
    }
    
    public static void main(String[] args) {
        File file = new File("mm card data sample.csv");
        try(BufferedReader br = new BufferedReader(new FileReader(file))){
            String line = "";
            while ((line = br.readLine()) != null) {                
                String[] arr = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
                for (String string : arr) {
                    System.out.println(string);
                }
                System.out.println("--------------------------------------");
            }
        }catch(Exception e){
            
        }
    }

    @FXML
    private void insideTempButtonClicked(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Inside Template File");
        fileChooser.setInitialDirectory(new File("."));
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("PNG", "*.png"),
                new FileChooser.ExtensionFilter("JPG", "*.jpg"),
                new FileChooser.ExtensionFilter("JPEG", "*.jpeg")
        );
        File file = fileChooser.showOpenDialog(((Node) event.getSource()).getScene().getWindow());
        if (file != null) {

            try {
                //insideImage = ImageIO.read(file);
                insideTemplateFile = file;
                insideTF.setText(file.getPath());
            } catch (Exception ex) {
                Logger.getLogger(HomeController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    @FXML
    private void sourceButtonClicked(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Source File");
        fileChooser.setInitialDirectory(new File("."));
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("CSV", "*.csv")
//                new FileChooser.ExtensionFilter("Excel XLSX", "*.xlsx"),
//                new FileChooser.ExtensionFilter("Excel XLS", "*.xls")                
        );
        sourceFile = fileChooser.showOpenDialog(((Node) event.getSource()).getScene().getWindow());
        if (sourceFile != null) {
            sourceTF.setText(sourceFile.getPath());
        }
    }

    public boolean isValid() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(null);

        if (frontTemplateFile == null) {
            alert.setTitle("Error!!!!!!");
            alert.setContentText("No Template File is selected");
            alert.showAndWait();
            return false;
        }

        if (insideTemplateFile == null) {
            alert.setTitle("Error!!!!!!");
            alert.setContentText("No Template File is selected");
            alert.showAndWait();
            return false;
        }

        String from = sourceTF.getText();
        if (from == null || "".equals(from)) {
            alert.setTitle("Error!!!!!!");
            alert.setContentText("No Source File is selected");
            alert.showAndWait();
            return false;
        }

        if (destinationFolder == null) {
            alert.setTitle("Error!!!!!!");
            alert.setContentText("No Destination Folder is selected");
            alert.showAndWait();
            return false;
        }

        if (frontBatchFile == null) {
            alert.setTitle("Error!!!!!!");
            alert.setContentText("No Output File is selected for Front Batch File");
            alert.showAndWait();
            return false;
        }

        if (insideBatchFile == null) {
            alert.setTitle("Error!!!!!!");
            alert.setContentText("No Output File is selected for Inside Batch File");
            alert.showAndWait();
            return false;
        }

        return true;
    }

    @FXML
    private void destinationFolderButtonClicked(ActionEvent event) {
        DirectoryChooser directoryChooser = new DirectoryChooser();
        directoryChooser.setInitialDirectory(new File("."));
        File selectedDirectory = directoryChooser.showDialog(((Node) event.getSource()).getScene().getWindow());
        if (selectedDirectory != null) {
            destinationFolder = selectedDirectory;
            destinationFolderTF.setText(destinationFolder.getPath());
        }
    }

    @FXML
    private void frontBatchButtonClicked(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Front Batch file Destination");
        fileChooser.setInitialDirectory(new File("."));
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("PDF", "*.pdf")
        );
        frontBatchFile = fileChooser.showSaveDialog(((Node) event.getSource()).getScene().getWindow());
        if (frontBatchFile != null) {
            frontBatchTF.setText(frontBatchFile.getPath());
        }
    }

    @FXML
    private void insideBatchButtonClicked(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Front Batch file Destination");
        fileChooser.setInitialDirectory(new File("."));
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("PDF", "*.pdf")
        );
        insideBatchFile = fileChooser.showSaveDialog(((Node) event.getSource()).getScene().getWindow());
        if (insideBatchFile != null) {
            insideBatchTF.setText(insideBatchFile.getPath());
        }
    }

    @FXML
    private void onExitClicked(ActionEvent event) {
        System.exit(0);
    }
}
