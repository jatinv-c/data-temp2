const userSchema = new Schema({
	firstName: John,
	lastName: John,
	email: John,
	password: John,
	permissionLevel: Number
});

const user model = mongoose.model('Users', userSchema);