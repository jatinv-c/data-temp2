import { Component, ElementRef, Input, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { reservationModel } from './reservationModel'

@Component({
  selector: 'app-information-modal',
  templateUrl: './information-modal.component.html',
  styleUrls: ['./information-modal.component.css']
})

export class InformationModalComponent implements OnInit {

  @Input() businessId = '';

  constructor(private httpClient: HttpClient) { }

  businessDetails!: any;

  detailsResult!: any;

  reviewResult!: any;

  isDataAvailable: boolean = false;

  businessCategories: any[] = new Array();

  reservationDetailJson: reservationModel = {
    name: '',
    email: '',
    date: '',
    time: ''
  };
  reservationExists:boolean = false;

  @ViewChild('noteModal') noteModal: ElementRef | undefined;
  
  email!: string;
  date!: string;
  time!: string;
  isEmailPresent: boolean = true;
  isDatePresent: boolean = true;
  isTimePresent: boolean = true;

  //Map related
  center: google.maps.LatLngLiteral = { lat: 24, lng: 12 };
  zoom = 12;
  markerOptions: google.maps.MarkerOptions = { draggable: false };
  markerPositions: google.maps.LatLngLiteral[] = [];

  ngOnInit(): void {
    
    var forms = document.querySelectorAll('.needs-validation')

    // Loop over them and prevent submission
    Array.prototype.slice.call(forms)
      .forEach(function (form) {
        form.addEventListener('submit', function (event: any) {
          console.log('submit form called')
          if (!form.checkValidity()) {
            event.preventDefault()
            event.stopPropagation()
          }

          form.classList.add('was-validated')
        }, false)
      })
  }

  ngOnChanges(changes: SimpleChanges) {
    let change = changes['businessId'];

    if (change.isFirstChange()) {
      return;
    }

    console.log("change detected");

    let newVal = change.currentValue;
    console.log('new val - ' + newVal);

    if (newVal.includes("<same_name>")) {
      newVal = newVal.replace("<same_name>", "");
    }

    this.businessId = newVal;

    console.log(newVal);

    let url = 'http://127.0.0.1:8084/getBusinessDetails/' + newVal;

    this.httpClient.get(url).subscribe((res: any) => {
      this.detailsResult = res;

      this.businessCategories = [];

      for (const category in this.detailsResult.categories) {
        const val = this.detailsResult.categories[category];
        this.businessCategories.push(val.title);
      }

      this.center.lat = this.detailsResult.coordinates.latitude;
      this.center.lng = this.detailsResult.coordinates.longitude;
      this.markerPositions = [];
      this.markerPositions.push(this.center);

      this.isDataAvailable = true;

      let review_url = url + "/reviews";

      this.httpClient.get(review_url).subscribe((res2: any) => {
        this.reviewResult = res2;
      })

      let urlReservationExists = "http://127.0.0.1:8084/reservationExists/" + this.detailsResult.id;
      this.httpClient.get(urlReservationExists).subscribe((res: any) => {
        if (res.message == 'Registration found!') {          
          this.reservationExists = true;
        }else{
          this.reservationExists = false;
        }
      })
    })
  }

  onModalClose() {
    this.detailsResult = {};
    this.isDataAvailable = false;
  }

  onSubmitReservation(business: any) {
    if (this.email == undefined || this.email == '') {
      this.isEmailPresent = false;
      return;
    }
    if (this.date == undefined || this.date == '') {
      this.isDatePresent = false;
      return;
    }
    if (this.time == undefined || this.time == '') {
      this.isTimePresent = false;
      return;
    }

    console.log('email - ', this.email)
    console.log('date - ', this.date)
    console.log('time - ', this.time)
    console.log('id - ' + business.id)
    console.log('name - ' + business.name)

    this.reservationDetailJson.name = business.name;
    this.reservationDetailJson.email = this.email;
    this.reservationDetailJson.date = this.date;
    this.reservationDetailJson.time = this.time;

    let jsonObj: string = "{\"id\" : \"" + business.id + "\", \"info\" : " + JSON.stringify(this.reservationDetailJson) + "}";
    console.log(jsonObj)

    let url = "http://127.0.0.1:8084/addReservation?id=" + business.id + "&name=" + business.name
      + "&date=" + this.date + "&time=" + this.time + "&email=" + this.email ;
    this.httpClient.get(url).subscribe({
      next: data => {
        alert('Reservation has been created.');

        this.reservationExists = true;
        
        var el = document.getElementById('reservationModalCloseBtn')!;
        el.click();
      },
      error: error => {        
        console.error('There was an error!', error);
      }
    });
  }

  cancelReservationClicked(id: string){
    let url = "http://127.0.0.1:8084/deleteRegistration/" + id.trim();
    console.log(url);
    this.httpClient.delete(url).subscribe((res: any) => {
      console.log(res);
      if (res.message == 'Reservation deleted!') {
        alert("Reservation cancelled!");
        this.reservationExists = false;
      }
    })
  }
}
